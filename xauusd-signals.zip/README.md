# XAUUSD Signal Desk

A static, single-page gold structure dashboard: live gold price, a 1H candlestick chart with trend channels and support/resistance, and a rule-based market-structure model that trades only with the 1H bias. Includes Entry / Stop / Take Profit, a risk calculator and a local signal log.

No build step, no backend, no API key required. Deploy the folder to any static host (GitHub Pages, Netlify, Cloudflare Pages, Vercel).

---

## Quick start

```bash
# any static server works
cd xauusd-signals
python3 -m http.server 8080
# open http://localhost:8080
```

Opening `index.html` directly from disk (`file://`) also works in most browsers, but a local server is recommended so `fetch` and storage behave normally.

## Deploy to GitHub Pages (under 5 minutes)

1. Create a repository, e.g. `xauusd-signals`.
2. Upload everything inside this `xauusd-signals/` folder to the repository root (keep the `assets/` tree, `.nojekyll` and `index.html` together).
3. Repository **Settings → Pages → Build and deployment**:
   - Source: **Deploy from a branch**
   - Branch: `main`, folder `/ (root)` — then **Save**.
4. Wait ~1 minute; the site is live at `https://<username>.github.io/xauusd-signals/`.

The included `.nojekyll` file stops GitHub from processing the folder with Jekyll, so `assets/` is served as-is. No routing or server config needed — it is one HTML file plus static assets.

---

## What is on the page

| Area | What it does |
| --- | --- |
| Top bar | Live spot price, day open/high/low, feed status, London/New York session state, alerts and settings. |
| Chart | **1H only.** Candlesticks with EMA 9 / EMA 21 / SMA 50, an auto-detected trend channel, up to four S/R levels, and green/red risk-reward boxes for the active setup. |
| Structure card | Current 1H bias, allowed side, the key swing level, the exact condition that would flip the bias, Entry / Stop / TP1 / TP2 / TP3 with R multiples and the structural reasons. |
| Risk calculator | Account balance + risk % → risk amount, position size in lots and ounces, and profit at each target. |
| Signal log | Active and closed setups with status (TP1/TP2/TP3, SL, reversed, breakeven) and running stats. Stored in `localStorage`. |

### How the signal is built (1H structure only)

The model ignores indicators for direction. It reads swing structure on the 1H chart:

1. **Bias** — from the last confirmed swing highs and lows.
   - Higher highs **and** higher lows → **bullish**.
   - Lower highs **and** lower lows → **bearish**.
   - Anything mixed or contracting → **no bias, no trades**.
2. **Bias persistence** — the bias does **not** change because momentum, RSI, MACD or a single candle look strong. It only flips on the full sequence:
   - Bearish → bullish: a 1H **close above the key lower high**, then a confirmed **higher low that holds**.
   - Bullish → bearish: a 1H **close below the key higher low**, then a confirmed **lower high**.
   - After the close beyond the key level the structure is marked **questioned**: no new trades until the second step confirms or price closes back on the old side.
3. **Entries** — with the bias intact and no pending flip:
   - Bearish: **sells only**, at a lower-high retest/rejection or after a failed bullish breakout back below the key high.
   - Bullish: **buys only**, at a higher-low retest/rejection or after a failed bearish breakdown back above the key low.
   - Opposite signals are ignored regardless of momentum.
4. **Invalidation** — the stop sits just beyond the key structure level. A close beyond that level against the bias puts the structure under question and blocks new trades until confirmation. A completed flip closes any setup that was on the old side.

If price is far away from the key level, the bot waits for the retest instead of chasing. It is normal for it to sit out for long stretches when the 1H is ranging or contracting.

### Update cadence

- **3 s** — spot quote refresh (TradingView XAU/USD).
- **60 s** — candle refresh (Coinbase allows 300 bars per request).
- **3 min** — full 1H structure + bias recalculation, plus a recalculation when a new candle closes. A 20 s throttle prevents duplicate work.
- **Manual** — the **Structure** button (or the `r` key) forces an immediate recalculation.

An active setup is **locked** until its stop or a target is hit, or until the 1H structure completes a confirmed flip. After TP1 the stop is treated as breakeven; the setup closes at entry if price returns.

---

## Data sources

| Source | Used for | Key |
| --- | --- | --- |
| [TradingView](https://www.tradingview.com/symbols/XAUUSD/) `OANDA:XAUUSD` | Live spot quote: price, daily open / high / low and change %, streaming from TradingView's quote scanner | none |
| [Coinbase Exchange](https://docs.cdp.coinbase.com/exchange/docs) `PAXG-USD` | 1H candles. PAXG is a gold-backed token that tracks spot within a fraction of a percent; the series is rescaled to the live XAU/USD quote so chart levels and the header price agree | none |
| [gold-api.com](https://gold-api.com) | Fallback spot if the TradingView quote is unreachable | none |
| [Twelve Data](https://twelvedata.com) | Optional `XAU/USD` candles | free key |

In **Auto** mode the price you see is real spot gold from TradingView's OANDA XAU/USD feed, polled every 3 seconds, and the daily open / high / low / change come from the same feed. Candles are built from Coinbase's PAXG-USD book (the only keyless intraday gold series available), then shifted onto the spot basis so structure levels, entries and stops sit at the same prices as the quote.

### Adding a Twelve Data key (optional)

1. Get a free key at <https://twelvedata.com/pricing> (8 requests/min, 800/day).
2. On the site, click the source pill in the top-right (**Auto**).
3. Choose **Twelve Data**, paste the key, **Save**.

The key is stored only in this browser's `localStorage` (`xau_signal_desk:settings`). It is sent only to `api.twelvedata.com`. If the free quota is exhausted the app falls back to Coinbase candles and shows a notice.

### Settings

The gear button opens settings for data source, refresh speed, overlay visibility, alert sound/browser notifications and clearing stored data. **Reset data** removes the saved settings and signal log.

---

## Project layout

```
xauusd-signals/
├── index.html
├── .nojekyll
├── README.md
└── assets/
    ├── css/
    │   ├── base.css          variables, reset, typography
    │   ├── layout.css        app shell, top bar, workspace grid, responsive rules
    │   └── components.css    cards, buttons, chart chrome, signal card, log
    └── js/
        ├── config.js         tunables: intervals, timeframes, storage keys
        ├── utils.js          formatting, DOM helpers, storage, toasts
        ├── data.js           spot + candle fetching, chunked history, normalisation, cache
        ├── indicators.js     EMA, SMA, RSI, MACD, ATR, swing detection, linear regression
        ├── analysis.js       structure, trend channel, support/resistance
        ├── signals.js        scoring, plan and target construction
        ├── chart.js          Lightweight Charts wrapper, overlays, R:R boxes, autoscale
        ├── engine.js         state, refresh cadence, setup locking, trade evaluation
        ├── ui.js             all render functions
        └── app.js            event binding, keyboard shortcuts, boot
```

Charting uses **Lightweight Charts 4.2.3** (Apache-2.0), bundled locally in `assets/vendor/` so the site works without a CDN.

---

## Keyboard shortcuts

| Key | Action |
| --- | --- |
| `r` | Recalculate 1H structure now |
| `f` | Reset chart zoom |
| `s` | Open settings |
| `Esc` | Close dialogs |

---

## Limitations (read before trading)

- Public candle feeds are **not true XAU/USD interbank data**. PAXG tracks gold but has its own spreads and gaps; Twelve Data's free tier is delayed and rate-limited.
- Indicators are computed on closed and forming candles; the newest bar can repaint until it closes.
- Trade evaluation runs on the 8-second spot poll, so a wick that touches a level between polls may be missed or detected late.
- The model is deterministic structure rules, not a prediction engine. It has no order-flow, macro or news input.
- Swing points are confirmed with a two-bar lag, so a bias flip is always identified a little after the actual turning point.
- Structure-only means no counter-trend trades: in a contracting range the bot correctly stays flat until a clean HH+HL or LH+LL sequence appears.
- Everything is client-side: clearing browser data deletes the log and settings.

**This is an educational charting tool, not financial advice.** Trading gold carries a high risk of loss.

## License

Application code: MIT. Lightweight Charts: Apache-2.0 (see `assets/vendor/`).
