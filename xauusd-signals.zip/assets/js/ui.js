(function () {
  var U = XAU.utils;
  var $ = U.$;
  var el = {};

  function cache() {
    el = {
      livePrice: $("#livePrice"),
      liveChange: $("#liveChange"),
      dayOpen: $("#dayOpen"),
      dayHigh: $("#dayHigh"),
      dayLow: $("#dayLow"),
      dayRangeFill: $("#dayRangeFill"),
      liveDot: $("#liveDot"),
      feedStatus: $("#feedStatus"),
      sessionStatus: $("#sessionStatus"),
      sourceLabel: $("#sourceLabel"),
      sourceDot: $("#sourceDot"),
      chartBadge: $("#chartBadge"),
      loader: $("#chartLoader"),
      notice: $("#chartNotice"),
      lastUpdate: $("#lastUpdate"),
      card: $("#signalCard"),
      sigTf: $("#sigTf"),
      sigLock: $("#sigLock"),
      structureUpdate: $("#structureUpdate"),
      sigDir: $("#sigDir"),
      sigSub: $("#sigSub"),
      sigConfPill: $("#sigConfPill"),
      sigAllowed: $("#sigAllowed"),
      sigKey: $("#sigKey"),
      sigKeyLabel: $("#sigKeyLabel"),
      sigFlip: $("#sigFlip"),
      sigEntry: $("#sigEntry"),
      sigSl: $("#sigSl"),
      sigTp1: $("#sigTp1"),
      sigTp2: $("#sigTp2"),
      sigTp3: $("#sigTp3"),
      sigTp1R: $("#sigTp1R"),
      sigTp2R: $("#sigTp2R"),
      sigTp3R: $("#sigTp3R"),
      sigRR: $("#sigRR"),
      sigDist: $("#sigDist"),
      sigReasons: $("#sigReasons"),
      sigTime: $("#sigTime"),
      rsiReadout: $("#rsiReadout"),
      macdReadout: $("#macdReadout"),
      logList: $("#logList"),
      logStats: $("#logStats"),
      calcBalance: $("#calcBalance"),
      calcRisk: $("#calcRisk"),
      calcEntry: $("#calcEntry"),
      calcSl: $("#calcSl"),
      calcRiskAmt: $("#calcRiskAmt"),
      calcLots: $("#calcLots"),
      calcOz: $("#calcOz"),
      calcTp1: $("#calcTp1"),
      calcTp2: $("#calcTp2"),
      calcTp3: $("#calcTp3"),
      calcMode: $("#calcMode"),
      modal: $("#settingsModal"),
      toasts: $("#toasts"),
      footerClock: $("#footerClock"),
      sourceBtn: $("#sourceBtn"),
      alertBtn: $("#alertBtn"),
      refreshFill: $("#refreshFill"),
      refreshline: $(".refreshline")
    };
  }

  function money(v, d) { return U.fmtMoney(v, d == null ? 2 : d); }

  function setText(node, text) {
    if (node && node.textContent !== text) node.textContent = text;
  }

  function renderQuote(spot, flash) {
    if (!spot || !isFinite(spot.price)) return;
    var prevText = el.livePrice.textContent;
    var newText = U.fmtPrice(spot.price);
    setText(el.livePrice, newText);
    if (flash && prevText && prevText !== newText) {
      var prevNum = parseFloat(prevText.replace(/,/g, ""));
      el.livePrice.classList.remove("flash-up", "flash-down");
      void el.livePrice.offsetWidth;
      el.livePrice.classList.add(spot.price >= prevNum ? "flash-up" : "flash-down");
      setTimeout(function () {
        el.livePrice.classList.remove("flash-up", "flash-down");
      }, 800);
    }
  }

  function renderHeader(result, spot, opts) {
    opts = opts || {};
    renderQuote(spot, false);
    if (!result) return;
    var price = spot && isFinite(spot.price) ? spot.price : result.price;
    var day = result.day;

    var pct = day ? day.changePct : 0;
    setText(el.liveChange, U.fmtPct(pct) + " today");
    el.liveChange.classList.toggle("is-up", pct >= 0);
    el.liveChange.classList.toggle("is-down", pct < 0);
    el.liveChange.title = day ? "vs previous session close " + U.fmtPrice(day.prevClose) : "";

    if (day) {
      setText(el.dayOpen, U.fmtPrice(day.open));
      setText(el.dayHigh, U.fmtPrice(day.high));
      setText(el.dayLow, U.fmtPrice(day.low));
      var range = Math.max(0.01, day.high - day.low);
      var pos = U.clamp(((price - day.low) / range) * 100, 0, 100);
      el.dayRangeFill.style.left = Math.max(0, pos - 12) + "%";
      el.dayRangeFill.style.width = "24%";
    }

    if (result.indicators) {
      var rsi = result.indicators.rsi;
      if (rsi !== null && isFinite(rsi)) {
        el.rsiReadout.innerHTML = 'RSI <b class="' + (rsi > 55 ? "pos" : rsi < 45 ? "neg" : "") + '">' + rsi.toFixed(1) + "</b>";
      }
      var hist = result.indicators.hist;
      if (hist !== null && isFinite(hist)) {
        el.macdReadout.innerHTML = 'MACD <b class="' + (hist >= 0 ? "pos" : "neg") + '">' + (hist >= 0 ? "+" : "−") + Math.abs(hist).toFixed(2) + "</b>";
      }
    }
  }

  function renderSignal(result, tfKey, opts) {
    if (!result) return;
    opts = opts || {};
    var plan = result.plan;
    var side = result.side;
    var bias = result.bias || null;
    var mode = result.mode || (plan ? "setup" : "waiting");
    var locked = !!(opts.locked || result.locked);
    var prevSide = el.card.dataset.side || "";
    var status = result.status || "active";
    var tone = side === "NEUTRAL" ? (bias && bias.side === "BEARISH" ? "SELL" : bias && bias.side === "BULLISH" ? "BUY" : "NEUTRAL") : side;

    el.card.classList.remove("is-buy", "is-sell", "is-neutral");
    el.card.classList.add(tone === "BUY" ? "is-buy" : tone === "SELL" ? "is-sell" : "is-neutral");
    el.card.classList.toggle("is-locked", locked && mode === "setup");
    if (el.sigLock) el.sigLock.style.display = locked && mode === "setup" ? "inline-flex" : "none";
    setText(el.sigDir, mode === "setup" ? side : "WAIT");
    setText(el.sigTf, tfKey || result.tf);
    var sub;
    if (mode === "setup") {
      sub = result.setupLabel || (side === "BUY" ? "Higher-low entry" : "Lower-high entry");
      if (status === "tp1") sub += " · TP1 secured";
      else if (status === "tp2") sub += " · TP2 secured";
      else sub += locked ? " · entry locked" : " · market entry";
    } else if (mode === "waiting") {
      if (bias && bias.state === "questioned") {
        sub = (bias.side === "BEARISH" ? "Bearish" : "Bullish") + " bias · structure questioned";
      } else if (result.preview) {
        sub = "Preview — " + result.preview.note.replace(/^Triggers/, "triggers");
      } else if (result.waitText) {
        sub = result.waitText;
      } else {
        sub = bias && bias.side === "BEARISH" ? "Bearish bias — waiting for a lower-high retest"
          : bias && bias.side === "BULLISH" ? "Bullish bias — waiting for a higher-low retest"
          : "No bias — waiting for structure";
      }
    } else {
      sub = "No clear structure — stand aside";
    }
    setText(el.sigSub, sub);

    setText(el.sigAllowed, bias ? bias.allowed : "No trades");
    setText(el.sigKeyLabel, bias && bias.side ? bias.keyLabel : "Key level");
    setText(el.sigKey, bias && isFinite(bias.keyLevel) ? U.fmtPrice(bias.keyLevel) : "—");
    setText(el.sigFlip, bias ? bias.flipText : "Wait for a clean HH + HL or LH + LL");
    el.sigConfPill.className = "conf " + (bias && bias.side === "BEARISH" ? "conf--bear" : bias && bias.side === "BULLISH" ? "conf--bull" : "low");
    setText(el.sigConfPill, bias && bias.side ? bias.side : "NO BIAS");

    var rows = [el.sigEntry, el.sigSl, el.sigTp1, el.sigTp2, el.sigTp3];
    var rLabels = [el.sigTp1R, el.sigTp2R, el.sigTp3R];

    if (plan) {
      el.card.classList.remove("is-preview");
      setText(el.sigEntry, U.fmtPrice(plan.entry));
      setText(el.sigSl, U.fmtPrice(plan.sl));
      plan.tps.forEach(function (tp, i) {
        setText([el.sigTp1, el.sigTp2, el.sigTp3][i], U.fmtPrice(tp.price));
        setText(rLabels[i], tp.r.toFixed(2) + "R");
      });
      setText(el.sigRR, "1 : " + plan.rr.toFixed(2));
      setText(el.sigDist, plan.stopPts.toFixed(2) + " pts");
      rows.forEach(function (r) { r.closest(".level").classList.remove("is-empty"); });
    } else if (result.preview) {
      var pv = result.preview;
      setText(el.sigEntry, U.fmtPrice(pv.entry));
      setText(el.sigSl, U.fmtPrice(pv.sl));
      pv.tps.forEach(function (tp, i) {
        setText([el.sigTp1, el.sigTp2, el.sigTp3][i], U.fmtPrice(tp.price));
        setText(rLabels[i], tp.r.toFixed(2) + "R");
      });
      setText(el.sigRR, "1 : " + pv.rr.toFixed(2));
      setText(el.sigDist, pv.stopPts.toFixed(2) + " pts");
      rows.forEach(function (r) { r.closest(".level").classList.remove("is-empty"); });
      el.card.classList.add("is-preview");
    } else {
      el.card.classList.remove("is-preview");
      rows.forEach(function (r) { setText(r, "—"); r.closest(".level").classList.add("is-empty"); });
      rLabels.forEach(function (r) { setText(r, "—"); });
      setText(el.sigRR, "—");
      setText(el.sigDist, "—");
    }

    var reasons = result.reasons || [];
    var html = reasons.map(function (r) {
      return "<li>" + U.escapeHtml(r.text) + "</li>";
    }).join("");
    if (el.sigReasons.innerHTML !== html) el.sigReasons.innerHTML = html;

    var info;
    if (mode === "neutral") {
      info = (tfKey || result.tf) + " · waiting for structure";
    } else if (mode === "waiting") {
      info = (tfKey || result.tf) + " · bias " + bias.side.toLowerCase() + " · key " + U.fmtPrice(bias.keyLevel);
    } else {
      info = (tfKey || result.tf) + " · " + (locked ? "locked " : "") + U.fmtHM(result.at / 1000) + " · " + (bias ? bias.side.toLowerCase() : side.toLowerCase());
    }
    setText(el.sigTime, info);

    if (mode === "setup" && prevSide && prevSide !== side) {
      el.card.classList.remove("ping-buy", "ping-sell");
      void el.card.offsetWidth;
      el.card.classList.add(side === "BUY" ? "ping-buy" : "ping-sell");
      setTimeout(function () { el.card.classList.remove("ping-buy", "ping-sell"); }, 2400);
    }

    el.card.dataset.side = side;
  }

  function renderCalc(settings, plan) {
    var balance = U.toNum(el.calcBalance.value, settings.balance);
    var riskPct = U.toNum(el.calcRisk.value, settings.riskPct);
    var entry = U.toNum(el.calcEntry.value, 0);
    var sl = U.toNum(el.calcSl.value, 0);
    var riskAmt = balance * riskPct / 100;
    var dist = Math.abs(entry - sl);

    setText(el.calcRiskAmt, dist > 0 ? money(riskAmt) : "—");
    if (dist > 0 && riskAmt > 0) {
      var lots = riskAmt / (dist * 100);
      setText(el.calcLots, lots.toFixed(2) + " lots");
      setText(el.calcOz, U.fmtPrice(lots * 100, 1) + " oz exposure");
    } else {
      setText(el.calcLots, "—");
      setText(el.calcOz, "add entry & stop");
    }

    var baseEntry = entry > 0 ? entry : (plan ? plan.entry : 0);
    var tpNodes = [el.calcTp1, el.calcTp2, el.calcTp3];
    tpNodes.forEach(function (node, i) {
      var profit = plan && dist > 0 && baseEntry > 0 ? lotsProfit(riskAmt, dist, plan, i, baseEntry) : null;
      setText(node, profit === null || !isFinite(profit) ? "—" : money(profit));
    });
    setText(el.calcMode, plan ? (plan.side + " levels") : "manual");
  }

  function lotsProfit(riskAmt, dist, plan, i, entry) {
    if (!plan) return null;
    var lots = riskAmt / (dist * 100);
    return lots * 100 * Math.abs(plan.tps[i].price - entry);
  }

  function setCalcLevels(plan) {
    if (!plan) {
      el.calcEntry.value = "";
      el.calcSl.value = "";
      return;
    }
    el.calcEntry.value = plan.entry.toFixed(2);
    el.calcSl.value = plan.sl.toFixed(2);
  }

  function renderLog(entries) {
    if (!el.logList) return;
    entries = entries.filter(function (e) { return e.status !== "archived"; });
    if (!entries.length) {
      el.logList.innerHTML = '<li class="empty">No signals yet. Setups appear here as they form.</li>';
      renderStats(entries);
      return;
    }
    var html = entries.slice(0, 20).map(function (e) {
      var resClass = "active", resText = "Open";
      if (e.status === "sl") { resClass = "loss"; resText = "SL · −1.00R"; }
      else if (e.status === "tp1") { resClass = "win"; resText = "TP1 · +" + e.tps[0].r.toFixed(2) + "R"; }
      else if (e.status === "tp2") { resClass = "win"; resText = "TP2 · +" + e.tps[1].r.toFixed(2) + "R"; }
      else if (e.status === "tp3") { resClass = "win"; resText = "TP3 · +" + e.tps[2].r.toFixed(2) + "R"; }
      else if (e.status === "reversed") { resClass = (e.r || 0) >= 0 ? "win" : "loss"; resText = "REV · " + U.fmtR(e.r || 0); }
      else if (e.status === "closed") { resClass = "be"; resText = "CLOSED · " + U.fmtR(e.r || 0); }
      else if (e.status === "archived") { resClass = "be"; resText = "ARCHIVED"; }
      var dirClass = e.side === "BUY" ? "buy" : "sell";
      return '<li class="logitem">' +
        '<span class="logitem__badge ' + dirClass + '">' + e.side + '</span>' +
        '<div class="logitem__mid">' +
        '<div class="logitem__title">' + e.tf + ' <span>' + U.fmtTimeUTC(e.ts / 1000) + ' UTC</span></div>' +
        '<div class="logitem__levels">E ' + U.fmtPrice(e.entry) + ' · SL ' + U.fmtPrice(e.sl) + ' · TP1 ' + U.fmtPrice(e.tps[0].price) + '</div>' +
        '</div>' +
        '<span class="logitem__res ' + resClass + '">' + resText + '</span>' +
        '</li>';
    }).join("");
    el.logList.innerHTML = html;
    renderStats(entries);
  }

  function renderStats(entries) {
    if (!el.logStats) return;
    var resolved = entries.filter(function (e) { return e.status !== "active" && e.status !== "archived"; });
    var resultR = function (e) {
      if (isFinite(e.r)) return e.r;
      if (e.status === "sl") return -1;
      if (e.status === "tp1") return e.tps[0].r;
      if (e.status === "tp2") return e.tps[1].r;
      if (e.status === "tp3") return e.tps[2].r;
      return 0;
    };
    var wins = resolved.filter(function (e) { return resultR(e) > 0; });
    var winRate = resolved.length ? Math.round((wins.length / resolved.length) * 100) : 0;
    var totalR = 0;
    resolved.forEach(function (e) { totalR += resultR(e); });
    var avgR = resolved.length ? totalR / resolved.length : 0;
    el.logStats.innerHTML =
      '<div class="logstat"><b>' + entries.length + '</b><span>Signals</span></div>' +
      '<div class="logstat"><b>' + (resolved.length ? winRate + "%" : "—") + '</b><span>Win rate</span></div>' +
      '<div class="logstat"><b class="' + (avgR >= 0 ? "pos" : "neg") + '">' + (resolved.length ? U.fmtR(avgR) : "—") + '</b><span>Avg result</span></div>';
  }

  function toast(opts) {
    if (!el.toasts) return;
    var node = document.createElement("div");
    node.className = "toast toast--" + (opts.kind || "info");
    node.innerHTML =
      '<span class="toast__bar"></span>' +
      '<div class="toast__body">' +
      '<div class="toast__title">' + U.escapeHtml(opts.title) + (opts.tag ? "<em>" + U.escapeHtml(opts.tag) + "</em>" : "") + "</div>" +
      (opts.msg ? '<div class="toast__msg">' + opts.msg + "</div>" : "") +
      "</div>" +
      '<button class="toast__close" type="button" aria-label="Dismiss">×</button>';
    el.toasts.appendChild(node);
    var timer = setTimeout(remove, opts.ttl || 7000);
    function remove() {
      clearTimeout(timer);
      node.classList.add("is-out");
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 220);
    }
    node.querySelector(".toast__close").addEventListener("click", remove);
    while (el.toasts.children.length > 4) el.toasts.removeChild(el.toasts.firstChild);
  }

  function setFeed(status) {
    if (!el.feedStatus) return;
    setText(el.feedStatus, status.text);
    el.liveDot.className = "dot " + (status.kind === "live" ? "is-live" : status.kind === "warn" ? "is-warn" : "is-dead");
  }

  function setSource(label, live, detail) {
    setText(el.sourceLabel, label);
    el.sourceDot.className = "dot " + (live ? "dot--green" : "dot--gold");
    el.sourceBtn.title = (detail ? detail + " · " : "Data source: " + label + " · ") + "click to change";
  }

  function setSession(text) {
    setText(el.sessionStatus, text);
  }

  function setLoading(on, text) {
    if (!el.loader) return;
    if (on) {
      el.loader.hidden = false;
      var span = el.loader.querySelector("span");
      if (span && text) span.textContent = text;
    } else {
      el.loader.hidden = true;
    }
  }

  function showNotice(msg) {
    if (!el.notice) return;
    if (!msg) { el.notice.hidden = true; return; }
    el.notice.textContent = msg;
    el.notice.hidden = false;
  }

  function setChartBadge(tf, sourceLabel) {
    setText(el.chartBadge, tf + " · " + sourceLabel);
  }

  function setUpdated(ts, sourceLabel) {
    setText(el.lastUpdate, "Spot " + U.fmtClockUTC(ts / 1000) + " UTC · " + sourceLabel);
  }

  function setStructureTime(ts) {
    if (!el.structureUpdate) return;
    if (!ts) { setText(el.structureUpdate, "Structure —"); return; }
    setText(el.structureUpdate, "Structure " + U.fmtTimeUTC(ts / 1000) + " UTC");
    setStructureAge(ts);
  }

  function setStructureAge(ts) {
    if (!el.structureUpdate || !ts) return;
    el.structureUpdate.title = "Channels, support/resistance and signals recalculated " + U.timeAgo(ts / 1000) +
      ". Auto refresh every 3 min and on each candle close.";
  }

  function openSettings(settings) {
    $("#setSource").value = settings.source;
    $("#setApiKey").value = settings.apiKey || "";
    $("#setSound").checked = !!settings.sound;
    $("#setNotify").checked = !!settings.notify;
    $("#setFlash").checked = !!settings.flash;
    $("#setAutoScale").checked = !!settings.autoScale;
    $("#setCountdown").checked = !!settings.countdown;
    $("#keyStatus").textContent = "";
    $("#keyStatus").className = "hint";
    el.modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeSettings() {
    el.modal.hidden = true;
    document.body.style.overflow = "";
  }

  function readSettingsForm() {
    return {
      source: $("#setSource").value,
      apiKey: $("#setApiKey").value.trim(),
      sound: $("#setSound").checked,
      notify: $("#setNotify").checked,
      flash: $("#setFlash").checked,
      autoScale: $("#setAutoScale").checked,
      countdown: $("#setCountdown").checked
    };
  }

  function setAlertState(on) {
    el.alertBtn.classList.toggle("is-on", on);
    el.alertBtn.setAttribute("aria-pressed", on ? "true" : "false");
    el.alertBtn.title = on ? "Alerts enabled — click to mute" : "Enable sound alerts";
  }

  function setRefreshVisible(on) {
    if (el.refreshline) el.refreshline.classList.toggle("is-hidden", !on);
  }

  function setRefreshProgress(p) {
    if (el.refreshFill) el.refreshFill.style.width = U.clamp(p, 0, 100).toFixed(1) + "%";
  }

  function setClock(text) { setText(el.footerClock, text); }

  function confirmAction(msg) { return window.confirm(msg); }

  XAU.ui = {
    cache: cache,
    el: function () { return el; },
    renderHeader: renderHeader,
    renderQuote: renderQuote,
    renderSignal: renderSignal,
    renderCalc: renderCalc,
    setCalcLevels: setCalcLevels,
    renderLog: renderLog,
    renderStats: renderStats,
    toast: toast,
    setFeed: setFeed,
    setSource: setSource,
    setSession: setSession,
    setLoading: setLoading,
    showNotice: showNotice,
    setChartBadge: setChartBadge,
    setUpdated: setUpdated,
    setStructureTime: setStructureTime,
    setStructureAge: setStructureAge,
    openSettings: openSettings,
    closeSettings: closeSettings,
    readSettingsForm: readSettingsForm,
    setAlertState: setAlertState,
    setRefreshVisible: setRefreshVisible,
    setRefreshProgress: setRefreshProgress,
    setClock: setClock,
    confirmAction: confirmAction
  };
})();
