(function () {
  var CFG = XAU.CONFIG;
  var U = XAU.utils;
  var TFS = ["M5", "M15", "H1", "H4"];
  var UI, D, chart;

  var state = {
    settings: null,
    tf: "M15",
    candles: [],
    spot: null,
    structure: null,
    structureAt: 0,
    structureCandle: 0,
    structureTf: "",
    structureBusy: false,
    activeSetup: null,
    chartPlanId: null,
    source: "—",
    lastSpotAt: 0,
    loadSeq: 0,
    sideCooldown: {},
    bias: null,
    log: [],
    timers: {},
    started: false
  };

  function $(sel) { return document.querySelector(sel); }

  function loadSettings() {
    var saved = U.storeGet(XAU.STORAGE_KEYS.settings, {}) || {};
    var merged = Object.assign({}, CFG.defaults, saved);
    merged.overlays = Object.assign({}, CFG.defaults.overlays, saved.overlays || {});
    if (TFS.indexOf(merged.tf) === -1) merged.tf = CFG.defaults.tf;
    return merged;
  }

  function persistSettings() {
    U.storeSet(XAU.STORAGE_KEYS.settings, state.settings);
  }

  function loadLog() {
    var raw = U.storeGet(XAU.STORAGE_KEYS.log, []);
    if (!Array.isArray(raw)) return [];
    return raw.filter(function (e) {
      return e && e.side && e.tf && isFinite(e.entry) && isFinite(e.sl) && Array.isArray(e.tps) && e.tps.length === 3;
    }).slice(0, CFG.maxLogEntries);
  }

  function dedupeOpenLogs() {
    var seen = {};
    var changed = false;
    state.log.forEach(function (e) {
      if (!isOpenStatus(e.status)) return;
      if (!seen[e.tf]) { seen[e.tf] = e; return; }
      e.status = "archived";
      e.closedAt = Date.now();
      e.r = null;
      changed = true;
    });
    if (changed) saveLog();
  }

  function saveLog() {
    state.log = state.log.slice(0, CFG.maxLogEntries);
    U.storeSet(XAU.STORAGE_KEYS.log, state.log);
  }

  function loadBias() {
    var raw = U.storeGet(XAU.STORAGE_KEYS.bias, null);
    return raw && typeof raw === "object" ? raw : null;
  }

  function saveBias() {
    if (state.bias) U.storeSet(XAU.STORAGE_KEYS.bias, state.bias);
  }

  function sourceLabelFor(src) {
    return { twelvedata: "Twelve Data", coinbase: "Coinbase PAXG", demo: "Simulated", "gold-api": "gold-api", tradingview: "TradingView XAU/USD" }[src] || src;
  }

  function combinedSource() {
    if (state.source === "demo") return "Demo";
    return sourceLabelFor(state.spot ? state.spot.source : state.source);
  }

  function sourceDetail() {
    return "Spot: " + sourceLabelFor(state.spot ? state.spot.source : "—") + " · Candles: " + sourceLabelFor(state.source);
  }

  function updateFeedStatus() {
    if (!state.spot) { UI.setFeed({ text: "Connecting…", kind: "warn" }); return; }
    var age = Date.now() - state.spot.at;
    var limits = { tradingview: 12000, "gold-api": 70000, coinbase: 45000 };
    var limit = limits[state.spot.source] || CFG.refreshMs * 3;
    if (!state.spot.live) UI.setFeed({ text: "Reconnecting · cached " + U.durationShort(age), kind: "dead" });
    else if (age > limit) UI.setFeed({ text: "Stale · " + U.timeAgo(state.spot.at / 1000), kind: "warn" });
    else UI.setFeed({ text: "Live · " + sourceLabelFor(state.spot.source), kind: "live" });
  }

  function updateSession() {
    var ms = U.marketState();
    UI.setSession(ms.label);
    if (!ms.open && state.structure) UI.showNotice("Market closed — showing the last session. New setups resume at the open.");
    else if (state.source !== "demo") UI.showNotice(null);
  }

  function updateClock() {
    var d = new Date();
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    UI.setClock(d.getUTCDate() + " " + months[d.getUTCMonth()] + " " + d.getUTCFullYear() + " · " +
      U.pad(d.getUTCHours()) + ":" + U.pad(d.getUTCMinutes()) + ":" + U.pad(d.getUTCSeconds()) + " UTC");
    if (state.settings.countdown && state.lastSpotAt) {
      UI.setRefreshProgress(((Date.now() - state.lastSpotAt) / CFG.refreshMs) * 100);
    }
    if (state.structureAt) UI.setStructureAge(state.structureAt);
  }

  function mergeLive(spot) {
    if (!state.structure || !spot || !isFinite(spot.price)) return;
    var price = spot.price;
    var day = state.structure.day;
    if (isFinite(spot.open) && spot.open > 0) day.open = spot.open;
    if (isFinite(spot.prevClose) && spot.prevClose > 0) day.prevClose = spot.prevClose;
    day.high = isFinite(spot.high) ? Math.max(spot.high, price) : Math.max(day.high, price);
    day.low = isFinite(spot.low) ? Math.min(spot.low, price) : Math.min(day.low, price);
    day.change = price - day.prevClose;
    day.changePct = day.prevClose ? (day.change / day.prevClose) * 100 : 0;
    state.structure.price = price;
  }

  function refreshSpot() {
    return D.fetchSpot().then(function (spot) {
      var had = !!state.spot;
      state.spot = spot;
      state.lastSpotAt = Date.now();
      updateFeedStatus();
      UI.setSource(combinedSource(), state.source !== "demo" && spot.live, sourceDetail());
      UI.renderQuote(spot, had && !!state.settings.flash);
      UI.setUpdated(spot.at, spot.source === "tradingview" ? "TradingView" : sourceLabelFor(spot.source));
      mergeLive(spot);
      if (state.structure) UI.renderHeader(state.structure, spot, { flash: false });

      var newBar = false;
      if (state.candles.length) newBar = applySpotToCandles(spot);
      evaluateTrades(spot.price);
      if (newBar) scheduleStructure("new candle", 2500);
      return spot;
    }).catch(function () {
      updateFeedStatus();
      return null;
    });
  }

  function applySpotToCandles(spot) {
    if (!spot || !isFinite(spot.price) || !U.marketState().open) return false;
    var t = CFG.timeframes[state.tf];
    var now = Math.floor(Date.now() / 1000);
    var last = state.candles[state.candles.length - 1];
    if (!last) return false;
    var barTime = now - (now % t.seconds);
    if (barTime > last.time) {
      var bar = {
        time: barTime, open: last.close,
        high: Math.max(last.close, spot.price), low: Math.min(last.close, spot.price),
        close: spot.price, volume: 0
      };
      state.candles.push(bar);
      chart.updateLast(bar);
      return true;
    }
    last.high = Math.max(last.high, spot.price);
    last.low = Math.min(last.low, spot.price);
    last.close = spot.price;
    chart.updateLast(last);
    return false;
  }

  function scheduleStructure(reason, delay) {
    clearTimeout(state.timers.structureDebounce);
    state.timers.structureDebounce = setTimeout(function () {
      recalculateStructure(reason);
    }, delay || 0);
  }

  function recalculateStructure(reason, opts) {
    opts = opts || {};
    if (!state.candles.length || state.candles.length < 60 || state.structureBusy) return;
    if (!opts.force && state.structureAt && Date.now() - state.structureAt < CFG.structureMinInterval) return;

    state.structureBusy = true;
    var result = null;
    try {
      result = XAU.analyze(state.candles, state.tf, state.bias);
    } finally {
      state.structureBusy = false;
    }
    if (!result) return;

    var prevBiasSide = state.bias && state.bias.side;
    var prevFlipAt = state.bias && state.bias.flippedAt;
    state.bias = result.biasState;
    saveBias();
    if (result.bias.flipped && result.bias.side !== prevBiasSide) {
      UI.toast({
        kind: result.bias.side === "BULLISH" ? "buy" : "sell",
        title: "Structure flipped · " + result.bias.side,
        tag: "FLIP",
        msg: result.bias.side === "BULLISH"
          ? "1H closed above the key high and printed a higher low. Buys only from here."
          : "1H closed below the key low and printed a lower high. Sells only from here.",
        ttl: 9000
      });
    }

    state.structure = result;
    state.structureAt = Date.now();
    state.structureCandle = state.candles[state.candles.length - 1].time;
    state.structureTf = state.tf;
    if (state.spot) mergeLive(state.spot);

    chart.setAnalysis(result.market);
    UI.renderHeader(result, state.spot, { flash: false });
    UI.setStructureTime(state.structureAt);

    reconcile(result, reason, opts);

  }

  function reconcile(result, reason, opts) {
    if (state.activeSetup && state.activeSetup.tf !== state.tf) {
      state.activeSetup = null;
      state.chartPlanId = null;
    }

    var activeLog = state.activeSetup ? findLog(state.activeSetup.logId) : null;
    if (state.activeSetup && (!activeLog || !isOpenStatus(activeLog.status))) {
      state.activeSetup = null;
      state.chartPlanId = null;
    }

    if (state.activeSetup) {
      if (result.mode === "neutral") { renderActive(); return; }
      if (result.side === state.activeSetup.side) { renderActive(); return; }
      var closed = findLog(state.activeSetup.logId);
      if (closed) {
        closeLogEntry(closed.id, "reversed", result.price);
        UI.toast({
          kind: result.side === "BUY" ? "buy" : "sell",
          title: "Structure flipped against the setup",
          msg: "The " + state.activeSetup.side + " setup was closed at " + U.fmtPrice(result.price) + " — the 1H bias is now " + (result.bias ? result.bias.side.toLowerCase() : "unclear") + ".",
          ttl: 8000
        });
      }
      state.activeSetup = null;
      state.chartPlanId = null;
      chart.setPlan(null);
    }

    if (result.mode === "setup") { adopt(result, reason, opts); return; }
    showNeutral(result);
    if (opts.manual) {
      UI.toast({
        kind: "info",
        title: "Structure recalculated",
        msg: result.bias && result.bias.side
          ? "1H bias " + result.bias.side.toLowerCase() + " · key " + U.fmtPrice(result.bias.keyLevel) + ". No valid entry yet."
          : "No clear 1H structure yet — no trades until a bias is established.",
        ttl: 5500
      });
    }
  }

  function adopt(result, reason, opts) {
    var plan = result.plan;
    if (!plan) return;
    var entry = {
      id: U.uid(),
      tf: result.tf,
      side: plan.side,
      entry: plan.entry,
      sl: plan.sl,
      tps: plan.tps.map(function (t) { return { price: t.price, r: t.r, label: t.label }; }),
      rr: plan.rr,
      score: 0,
      conf: 0,
      setupLabel: result.setupLabel || "Structure entry",
      bias: result.bias ? {
        side: result.bias.side, keyLevel: result.bias.keyLevel, keyLabel: result.bias.keyLabel,
        allowed: result.bias.allowed, flipText: result.bias.flipText, state: result.bias.state
      } : null,
      ts: Date.now(),
      status: "active",
      closedAt: null,
      r: null,
      reasons: result.reasons.map(function (r) { return r.text; }),
      source: state.source
    };
    state.log.unshift(entry);
    saveLog();
    UI.renderLog(state.log);
    state.activeSetup = {
      id: entry.id,
      logId: entry.id,
      tf: entry.tf,
      side: entry.side,
      confidence: 0,
      score: 0
    };
    state.chartPlanId = null;
    renderActive();

    if (!opts.initial && reason !== "restore") {
      announce(plan);
      UI.toast({
        kind: plan.side === "BUY" ? "buy" : "sell",
        title: plan.side + " signal · " + result.tf,
        tag: "NEW",
        msg: "Entry " + U.fmtPrice(entry.entry) + " · SL " + U.fmtPrice(entry.sl) +
          " · TP2 " + U.fmtPrice(entry.tps[1].price) + " · 1:" + entry.rr.toFixed(2),
        ttl: 9000
      });
    }
  }

  function announce(plan) {
    if (state.settings.sound) {
      try { U.beep(plan.side === "BUY" ? "buy" : "sell"); } catch (e) {}
    }
    if (state.settings.notify && "Notification" in window && Notification.permission === "granted") {
      U.notify("XAUUSD " + plan.side + " · " + state.tf,
        "Entry " + U.fmtPrice(plan.entry) + " · SL " + U.fmtPrice(plan.sl) +
        " · TP2 " + U.fmtPrice(plan.tps[1].price) + " · R:R 1:" + plan.rr.toFixed(2),
        "xau-" + state.tf + "-" + plan.side);
    }
  }

  function findLog(id) {
    for (var i = 0; i < state.log.length; i++) if (state.log[i].id === id) return state.log[i];
    return null;
  }

  function isOpenStatus(status) {
    return status === "active" || status === "tp1" || status === "tp2";
  }

  function setupFromLog(e) {
    return {
      id: e.id, logId: e.id, tf: e.tf, side: e.side,
      confidence: e.conf, score: e.score
    };
  }

  function activeView(e) {
    return {
      tf: e.tf, side: e.side, mode: "setup", setupLabel: e.setupLabel || "Structure entry",
      bias: e.bias || null, confidence: 0, score: 0,
      at: e.ts, locked: true, status: e.status,
      reasons: (e.reasons || []).map(function (t) { return { delta: 0, text: t }; }),
      plan: {
        side: e.side, entry: e.entry, sl: e.sl, tps: e.tps, rr: e.rr,
        rr1: e.tps[0].r, rr3: e.tps[2].r,
        stopPts: U.round(Math.abs(e.entry - e.sl), 2)
      }
    };
  }

  function renderActive() {
    var e = state.activeSetup ? findLog(state.activeSetup.logId) : null;
    if (!e || !isOpenStatus(e.status)) { showNeutral(state.structure); return; }
    var view = activeView(e);
    var forceCalc = state.chartPlanId !== e.id;
    UI.renderSignal(view, e.tf, { locked: true });
    if (forceCalc) {
      chart.setPlan(view.plan);
      state.chartPlanId = e.id;
    }
    syncCalc(view.plan, forceCalc);
  }

  function showNeutral(result, note, clearCalc) {
    var view = {
      tf: state.tf,
      side: result ? result.side : "NEUTRAL",
      mode: result ? result.mode : "neutral",
      bias: result ? result.bias : null,
      confidence: 0,
      score: 0,
      at: Date.now(),
      locked: false,
      plan: null,
      waitText: result ? result.waitText : "",
      reasons: note ? [{ delta: 0, text: note }] : (result ? result.reasons.slice(0, 4) : [{ delta: 0, text: "Waiting for the first structure calculation." }])
    };
    UI.renderSignal(view, state.tf);
    if (state.chartPlanId !== null) {
      chart.setPlan(null);
      state.chartPlanId = null;
    }
    syncCalc(null, !!clearCalc);
  }

  function syncCalc(plan, force) {
    var active = document.activeElement;
    var editing = active === UI.el().calcEntry || active === UI.el().calcSl;
    if (force && !editing) UI.setCalcLevels(plan);
    UI.renderCalc(state.settings, plan);
  }

  function closeLogEntry(id, status, price) {
    var e = findLog(id);
    if (!e) return null;
    var dir = e.side === "BUY" ? 1 : -1;
    var risk = Math.abs(e.entry - e.sl);
    e.status = status;
    e.closedAt = Date.now();
    e.r = risk > 0 ? U.round(((price - e.entry) * dir) / risk, 2) : 0;
    saveLog();
    UI.renderLog(state.log);
    return e;
  }

  function evaluateTrades(price) {
    if (!isFinite(price) || !state.log.length) return;
    var changed = false;
    state.log.forEach(function (e) {
      if (!isOpenStatus(e.status)) return;
      var dir = e.side === "BUY" ? 1 : -1;
      var tpSecured = e.status === "tp1" || e.status === "tp2";
      var slHit = !tpSecured && (price - e.sl) * dir <= 0;
      var reached = e.status === "tp2" ? 2 : e.status === "tp1" ? 1 : 0;
      for (var i = 0; i < 3; i++) {
        if ((price - e.tps[i].price) * dir >= 0) reached = Math.max(reached, i + 1);
      }
      if (slHit) {
        e.status = "sl";
        e.closedAt = Date.now();
        e.r = -1;
        changed = true;
        state.sideCooldown[e.tf + "|" + e.side] = Date.now();
        UI.toast({
          kind: "err", title: "Stop hit · " + e.side + " " + e.tf,
          msg: "−1.00R at " + U.fmtPrice(e.sl) + ". Setup invalidated; next setup can form after the cooldown.",
          ttl: 7000
        });
        return;
      }
      if (tpSecured && (price - e.entry) * dir <= 0) {
        var secured = e.tps[Math.max(0, reached - 1)];
        e.status = "closed";
        e.closedAt = Date.now();
        e.r = secured.r;
        changed = true;
        UI.toast({
          kind: "info", title: "Breakeven exit · " + e.side + " " + e.tf,
          msg: "Price returned to entry after TP" + Math.max(1, reached) + "; result booked at +" + secured.r.toFixed(2) + "R.",
          ttl: 6000
        });
        return;
      }
      if (reached > 0) {
        var status = "tp" + reached;
        if (status !== e.status) {
          e.status = status;
          e.r = e.tps[reached - 1].r;
          e.closedAt = reached === 3 ? Date.now() : null;
          changed = true;
          UI.toast({
            kind: "buy", title: "TP" + reached + " reached · " + e.side + " " + e.tf,
            msg: "Now +" + e.tps[reached - 1].r.toFixed(2) + "R at " + U.fmtPrice(e.tps[reached - 1].price),
            ttl: 6000
          });
        }
      }
    });

    if (changed) {
      saveLog();
      UI.renderLog(state.log);
    }

    if (state.activeSetup) {
      var activeLog = findLog(state.activeSetup.logId);
      if (!activeLog || !isOpenStatus(activeLog.status)) {
        state.activeSetup = null;
        state.chartPlanId = null;
        chart.setPlan(null);
        showNeutral(state.structure, "Setup finished — the model will look for the next valid entry on the next structure update.", true);
      } else if (changed) {
        renderActive();
      }
    }
  }

  function loadCandles(tf, opts) {
    opts = opts || {};
    var seq = ++state.loadSeq;
    if (opts.loader) UI.setLoading(true, "Loading " + tf + " market data…");
    return D.getCandles(tf, state.settings, state.spot).then(function (res) {
      if (seq !== state.loadSeq || tf !== state.tf) return;
      state.candles = res.candles;
      state.source = res.source;
      if (state.spot) applySpotToCandles(state.spot);
      chart.setData(state.candles, tf, { fit: !!opts.fit });
      UI.setLoading(false);
      UI.setChartBadge(tf, sourceLabelFor(res.source));
      UI.setSource(combinedSource(), res.source !== "demo", sourceDetail());
      updateFeedStatus();

      if (res.source === "demo") {
        UI.showNotice("Live candle feed unavailable — showing simulated data. Signals are illustrative.");
      } else if (!U.marketState().open) {
        UI.showNotice("Market closed — showing the last session. New setups resume at the open.");
      } else {
        UI.showNotice(null);
      }

      if (state.spot) evaluateTrades(state.spot.price);
      var lastTime = res.candles[res.candles.length - 1].time;
      var needsStructure = opts.forceStructure || !state.structure || state.structureTf !== tf || lastTime > state.structureCandle;
      if (needsStructure) {
        recalculateStructure("candles", { initial: !!opts.initial, force: true, manual: !!opts.manual });
      }
      return res;
    }).catch(function (err) {
      if (seq !== state.loadSeq) return;
      UI.setLoading(false);
      UI.showNotice("Candle feed error — retrying shortly.");
      UI.toast({ kind: "err", title: "Data error", msg: U.escapeHtml(err && err.message ? err.message : "Unknown error"), ttl: 6000 });
    });
  }

  function switchTf(tf) {
    if (!CFG.timeframes[tf] || tf === state.tf || tf !== "H1") return;
    state.tf = tf;
    U.storeSet(XAU.STORAGE_KEYS.tf, tf);
    UI.setChartBadge(tf, sourceLabelFor(state.source));
    UI.setLoading(true, "Loading " + tf + " structure…");
    UI.showNotice(null);
    state.activeSetup = null;
    state.chartPlanId = null;
    state.structure = null;
    chart.setPlan(null);
    var existing = state.log.filter(function (e) { return e.tf === tf && isOpenStatus(e.status); })[0];
    if (existing) state.activeSetup = setupFromLog(existing);
    showNeutral(null, "Loading " + tf + " structure and scanning for a valid setup…");
    loadCandles(tf, { fit: true, loader: true, forceStructure: true });
  }

  function setOverlays(ov) {
    state.settings.overlays = ov;
    persistSettings();
    chart.setOverlays(ov);
  }

  function toggleOverlay(key) {
    var ov = Object.assign({}, state.settings.overlays);
    ov[key] = !ov[key];
    setOverlays(ov);
    return ov;
  }

  function saveSettings(form) {
    var dataChanged = form.source !== state.settings.source || form.apiKey !== state.settings.apiKey;
    state.settings = Object.assign({}, state.settings, form);
    persistSettings();
    return dataChanged;
  }

  function clearLog() {
    state.log = [];
    state.sideCooldown = {};
    saveLog();
    UI.renderLog(state.log);
  }

  function restoreActive() {
    var existing = state.log.filter(function (e) { return e.tf === state.tf && isOpenStatus(e.status); })[0];
    if (existing) state.activeSetup = setupFromLog(existing);
  }

  function start() {
    UI.setLoading(true, "Connecting to live gold feed…");
    UI.renderLog(state.log);
    restoreActive();
    if (state.activeSetup) {
      var e = findLog(state.activeSetup.logId);
      if (e) {
        UI.renderSignal(activeView(e), e.tf, { locked: true });
        syncCalc(activeView(e).plan, true);
      }
    }
    UI.setStructureTime(state.structureAt);
    UI.setSource(combinedSource(), false, sourceDetail());
    UI.setAlertState(!!state.settings.sound);
    UI.setRefreshVisible(!!state.settings.countdown);
    UI.el().calcBalance.value = state.settings.balance;
    UI.el().calcRisk.value = state.settings.riskPct;
    updateSession();
    updateClock();

    state.started = true;
    state.timers.clock = setInterval(updateClock, 1000);
    state.timers.session = setInterval(updateSession, 30000);

    refreshSpot().then(function () {
      return loadCandles(state.tf, { fit: true, loader: true, initial: true, forceStructure: true });
    }).finally(function () {
      if (!state.timers.spot) {
        (function spotLoop() {
          if (document.hidden) {
            state.timers.spot = setTimeout(spotLoop, CFG.refreshMs);
            return;
          }
          refreshSpot().finally(function () {
            state.timers.spot = setTimeout(spotLoop, CFG.refreshMs);
          });
        })();
      }
      if (!state.timers.structure) {
        state.timers.structure = setInterval(function () {
          if (!document.hidden) recalculateStructure("timer");
        }, CFG.structureRefreshMs);
      }
      if (!state.timers.candles) {
        state.timers.candles = setInterval(function () {
          if (!document.hidden) loadCandles(state.tf, { fit: false });
        }, CFG.candleRefreshMs);
      }
    });

    document.addEventListener("visibilitychange", function () {
      if (document.hidden) return;
      refreshSpot();
      loadCandles(state.tf, { fit: false });
      if (state.structureAt && Date.now() - state.structureAt > CFG.structureRefreshMs) {
        recalculateStructure("resume");
      }
    });
  }

  function init(opts) {
    UI = opts.ui;
    D = XAU.data;
    chart = opts.chart;
    state.settings = loadSettings();
    state.log = loadLog();
    state.bias = loadBias();
    dedupeOpenLogs();
    state.tf = "H1";
    U.storeSet(XAU.STORAGE_KEYS.tf, "H1");
    return state;
  }

  XAU.engine = {
    init: init,
    start: start,
    state: state,
    refreshSpot: refreshSpot,
    loadCandles: loadCandles,
    switchTf: switchTf,
    recalculateStructure: recalculateStructure,
    setOverlays: setOverlays,
    toggleOverlay: toggleOverlay,
    saveSettings: saveSettings,
    persistSettings: persistSettings,
    clearLog: clearLog,
    syncCalc: syncCalc,
    activePlan: function () {
      var e = state.activeSetup ? findLog(state.activeSetup.logId) : null;
      return e && isOpenStatus(e.status) ? activeView(e).plan : null;
    },
    activeEntry: function () {
      return state.activeSetup ? findLog(state.activeSetup.logId) : null;
    },
    structure: function () { return state.structure; },
    findLog: findLog,
    isOpenStatus: isOpenStatus
  };
})();
