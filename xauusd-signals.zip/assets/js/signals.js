(function () {
  var U = XAU.utils;

  function lastOf(arr) { return arr && arr.length ? arr[arr.length - 1] : null; }
  function prevOf(arr) { return arr && arr.length > 1 ? arr[arr.length - 2] : null; }

  function targetCandidates(m, side) {
    var entry = m.price;
    var sign = side === "BUY" ? 1 : -1;
    var list = [];
    var ch = m.channel;

    if (ch) {
      list.push({ price: ch.upperEnd, label: "channel top" });
      list.push({ price: ch.mid.slope * ch.endIndex + ch.mid.intercept, label: "channel mid" });
      list.push({ price: ch.lowerEnd, label: "channel base" });
    }

    m.levels.forEach(function (l) {
      list.push({ price: l.price, label: (l.type === "resistance" ? "resistance" : "support") + " (" + l.touches + " touches)" });
    });

    if (m.day) {
      list.push({ price: m.day.high, label: "session high" });
      list.push({ price: m.day.low, label: "session low" });
    }

    var seen = [];
    list = list.filter(function (c) {
      if (!isFinite(c.price)) return false;
      if ((c.price - entry) * sign <= 0) return false;
      var dup = seen.some(function (p) { return Math.abs(p - c.price) < m.atr * 0.15; });
      if (dup) return false;
      seen.push(c.price);
      return true;
    }).sort(function (a, b) {
      return Math.abs(a.price - entry) - Math.abs(b.price - entry);
    });

    return list;
  }

  function buildTargets(m, side, risk) {
    var entry = m.price;
    var sign = side === "BUY" ? 1 : -1;
    var candidates = targetCandidates(m, side);
    var minR = [1.1, 2.2, 3.1];
    var maxR = [2.0, 3.2, 5.5];
    var fallback = [1.5, 2.5, 3.8];
    var used = [];
    var out = [];

    function priceAtR(r) { return entry + sign * risk * r; }
    function rAt(p) { return ((p - entry) * sign) / risk; }

    candidates.forEach(function (c) { c.r = rAt(c.price); });

    for (var i = 0; i < 3; i++) {
      var floorR = Math.max(minR[i], used.length ? used[used.length - 1] + 0.45 : 0);
      var pick = null;
      for (var j = 0; j < candidates.length; j++) {
        var c = candidates[j];
        if (c.r >= floorR && c.r <= maxR[i] && !used.some(function (u) { return u.label === c.label && Math.abs(u.price - c.price) < 0.01; })) {
          pick = c;
          break;
        }
      }
      var price, label;
      if (pick) {
        price = pick.price;
        label = pick.label;
      } else {
        price = priceAtR(Math.max(fallback[i], floorR));
        label = "measured move";
      }
      if (i === 0) price = side === "BUY" ? Math.max(price, priceAtR(1.05)) : Math.min(price, priceAtR(1.05));
      price = U.round(price, 2);
      if (i > 0) {
        var prevR = out[i - 1].r;
        if (rAt(price) < prevR + 0.35) price = U.round(priceAtR(prevR + 0.55), 2);
      }
      out.push({ price: price, r: rAt(price), label: label });
    }
    return out;
  }

  function normalizeBias(saved) {
    var b = saved && typeof saved === "object" ? saved : {};
    var side = b.side === "BULLISH" || b.side === "BEARISH" ? b.side : null;
    return {
      side: side,
      keyLevel: isFinite(b.keyLevel) ? b.keyLevel : null,
      keyIndex: isFinite(b.keyIndex) ? b.keyIndex : null,
      keyTime: isFinite(b.keyTime) ? b.keyTime : null,
      pending: b.pending && isFinite(b.pending.level) ? {
        to: b.pending.to === "BULLISH" ? "BULLISH" : "BEARISH",
        level: b.pending.level,
        breakIndex: isFinite(b.pending.breakIndex) ? b.pending.breakIndex : 0,
        prevLow: isFinite(b.pending.prevLow) ? b.pending.prevLow : null,
        prevHigh: isFinite(b.pending.prevHigh) ? b.pending.prevHigh : null
      } : null,
      flippedAt: isFinite(b.flippedAt) ? b.flippedAt : 0,
      since: isFinite(b.since) ? b.since : 0
    };
  }

  function countSteps(points, atr) {
    var up = 0, down = 0;
    for (var i = 1; i < points.length; i++) {
      var d = points[i].price - points[i - 1].price;
      if (d > atr * 0.05) up++;
      else if (d < -atr * 0.05) down++;
    }
    return { up: up, down: down };
  }

  function evaluate(m, tfKey, savedBias, opts) {
    opts = opts || {};
    var atr = Math.max(m.atr, 0.01);
    var candles = m.candles;
    var n = candles.length;
    var live = candles[n - 1];
    var closed = candles[n - 2] || live;
    var prev = candles[n - 3] || closed;
    var piv = m.pivots || { highs: [], lows: [] };
    var hi1 = lastOf(piv.highs), hi2 = prevOf(piv.highs);
    var lo1 = lastOf(piv.lows), lo2 = prevOf(piv.lows);
    var price = m.price;

    var higherHigh = !!(hi1 && hi2 && hi1.price > hi2.price + atr * 0.05);
    var lowerHigh = !!(hi1 && hi2 && hi1.price < hi2.price - atr * 0.05);
    var higherLow = !!(lo1 && lo2 && lo1.price > lo2.price + atr * 0.05);
    var lowerLow = !!(lo1 && lo2 && lo1.price < lo2.price - atr * 0.05);

    var b = normalizeBias(savedBias);

    if (!b.side) {
      if (higherHigh && higherLow) {
        b.side = "BULLISH";
        b.keyLevel = lo1.price; b.keyIndex = lo1.index; b.keyTime = lo1.time;
        b.since = Date.now();
      } else if (lowerHigh && lowerLow) {
        b.side = "BEARISH";
        b.keyLevel = hi1.price; b.keyIndex = hi1.index; b.keyTime = hi1.time;
        b.since = Date.now();
      } else {
        var hs = countSteps(piv.highs.slice(-5), atr);
        var ls = countSteps(piv.lows.slice(-5), atr);
        if (hs.up >= 2 && ls.up >= 2 && hs.up > hs.down && ls.up > ls.down) {
          b.side = "BULLISH";
          b.keyLevel = lo1.price; b.keyIndex = lo1.index; b.keyTime = lo1.time;
          b.since = Date.now();
        } else if (hs.down >= 2 && ls.down >= 2 && hs.down > hs.up && ls.down > ls.up) {
          b.side = "BEARISH";
          b.keyLevel = hi1.price; b.keyIndex = hi1.index; b.keyTime = hi1.time;
          b.since = Date.now();
        }
      }
    }

    if (b.side && !isFinite(b.keyLevel)) {
      if (b.side === "BEARISH" && hi1) { b.keyLevel = hi1.price; b.keyIndex = hi1.index; b.keyTime = hi1.time; }
      if (b.side === "BULLISH" && lo1) { b.keyLevel = lo1.price; b.keyIndex = lo1.index; b.keyTime = lo1.time; }
    }

    var failedBreak = false;
    var flipped = false;

    if (b.side === "BEARISH" && isFinite(b.keyLevel)) {
      if (hi1 && hi1.index > (b.keyIndex || 0) && hi1.price < b.keyLevel - atr * 0.02) {
        b.keyLevel = hi1.price; b.keyIndex = hi1.index; b.keyTime = hi1.time;
      }
      if (!b.pending && closed.close > b.keyLevel + atr * 0.02) {
        b.pending = {
          to: "BULLISH", level: b.keyLevel, breakIndex: n - 2,
          prevLow: lo1 ? lo1.price : null, breakTime: closed.time
        };
      }
      if (b.pending) {
        if (closed.close < b.pending.level - atr * 0.02) {
          b.pending = null;
          failedBreak = true;
        } else {
          var higherLowHolds = lo1 && lo1.index > b.pending.breakIndex &&
            (b.pending.prevLow === null || lo1.price > b.pending.prevLow + atr * 0.05) &&
            closed.close > lo1.price;
          if (higherLowHolds) {
            b.side = "BULLISH"; b.keyLevel = lo1.price; b.keyIndex = lo1.index; b.keyTime = lo1.time;
            b.pending = null; b.flippedAt = Date.now(); flipped = true;
          }
        }
      }
    } else if (b.side === "BULLISH" && isFinite(b.keyLevel)) {
      if (lo1 && lo1.index > (b.keyIndex || 0) && lo1.price > b.keyLevel + atr * 0.02) {
        b.keyLevel = lo1.price; b.keyIndex = lo1.index; b.keyTime = lo1.time;
      }
      if (!b.pending && closed.close < b.keyLevel - atr * 0.02) {
        b.pending = {
          to: "BEARISH", level: b.keyLevel, breakIndex: n - 2,
          prevHigh: hi1 ? hi1.price : null, breakTime: closed.time
        };
      }
      if (b.pending) {
        if (closed.close > b.pending.level + atr * 0.02) {
          b.pending = null;
          failedBreak = true;
        } else {
          var lowerHighHolds = hi1 && hi1.index > b.pending.breakIndex &&
            (b.pending.prevHigh === null || hi1.price < b.pending.prevHigh - atr * 0.05) &&
            closed.close < hi1.price;
          if (lowerHighHolds) {
            b.side = "BEARISH"; b.keyLevel = hi1.price; b.keyIndex = hi1.index; b.keyTime = hi1.time;
            b.pending = null; b.flippedAt = Date.now(); flipped = true;
          }
        }
      }
    }

    var look = Math.min(20, n - 3);
    var rangeHigh = -Infinity, rangeLow = Infinity;
    for (var ri = n - 2 - look; ri <= n - 3; ri++) {
      if (ri < 0) continue;
      if (candles[ri].high > rangeHigh) rangeHigh = candles[ri].high;
      if (candles[ri].low < rangeLow) rangeLow = candles[ri].low;
    }

    var trigger = null;
    if (b.side && !b.pending && isFinite(b.keyLevel)) {
      var distAtr = (price - b.keyLevel) / atr;

      if (b.side === "BEARISH") {
        var nearShort = price <= b.keyLevel + atr * 0.35 && price >= b.keyLevel - atr * 0.9;
        var rejectedHigh = closed.high >= b.keyLevel - atr * 0.2 && closed.close < b.keyLevel - atr * 0.02 && nearShort;
        if (failedBreak || rejectedHigh) {
          trigger = {
            side: "SELL",
            kind: failedBreak ? "failed" : "retest",
            level: b.keyLevel,
            label: failedBreak ? "Failed bullish breakout" : "Lower-high rejection"
          };
        }
        if (!trigger && distAtr < -0.9 && isFinite(rangeLow)) {
          var freshBreakDown = closed.close < rangeLow - atr * 0.05 && prev.close >= rangeLow - atr * 0.05;
          var heldBreakDown = prev.close < rangeLow - atr * 0.05 &&
            closed.high >= rangeLow - atr * 0.25 && closed.close < rangeLow - atr * 0.1 && closed.close < closed.open;
          var breakingDownNow = live && closed.close >= rangeLow - atr * 0.05 &&
            live.open >= rangeLow - atr * 0.05 && price < rangeLow - atr * 0.1;
          if (freshBreakDown || heldBreakDown || breakingDownNow) {
            trigger = {
              side: "SELL",
              kind: "breakout",
              cont: true,
              level: rangeLow,
              label: freshBreakDown || breakingDownNow ? "Breakdown below the 20-bar low" : "Breakdown retest"
            };
          }
        }
      } else {
        var nearLong = price >= b.keyLevel - atr * 0.35 && price <= b.keyLevel + atr * 0.9;
        var rejectedLow = closed.low <= b.keyLevel + atr * 0.2 && closed.close > b.keyLevel + atr * 0.02 && nearLong;
        if (failedBreak || rejectedLow) {
          trigger = {
            side: "BUY",
            kind: failedBreak ? "failed" : "retest",
            level: b.keyLevel,
            label: failedBreak ? "Failed bearish breakdown" : "Higher-low rejection"
          };
        }
        if (!trigger && distAtr > 0.9 && isFinite(rangeHigh)) {
          var freshBreakUp = closed.close > rangeHigh + atr * 0.05 && prev.close <= rangeHigh + atr * 0.05;
          var heldBreakUp = prev.close > rangeHigh + atr * 0.05 &&
            closed.low <= rangeHigh + atr * 0.25 && closed.close > rangeHigh + atr * 0.1 && closed.close > closed.open;
          var breakingUpNow = live && closed.close <= rangeHigh + atr * 0.05 &&
            live.open <= rangeHigh + atr * 0.05 && price > rangeHigh + atr * 0.1;
          if (freshBreakUp || heldBreakUp || breakingUpNow) {
            trigger = {
              side: "BUY",
              kind: "breakout",
              cont: true,
              level: rangeHigh,
              label: freshBreakUp || breakingUpNow ? "Breakout above the 20-bar high" : "Breakout retest"
            };
          }
        }
      }
    }

    var plan = null;
    if (trigger && !opts.bootstrap) {
      var entry = price;
      var sl;
      if (trigger.side === "SELL") {
        sl = trigger.cont
          ? trigger.level + atr * 0.45
          : Math.max(b.keyLevel, closed.high) + atr * 0.3;
        sl = Math.max(sl, entry + atr * (trigger.cont ? 0.5 : 0.6));
        if (sl - entry > atr * 2.2) trigger = null;
      } else {
        sl = trigger.cont
          ? trigger.level - atr * 0.45
          : Math.min(b.keyLevel, closed.low) - atr * 0.3;
        sl = Math.min(sl, entry - atr * (trigger.cont ? 0.5 : 0.6));
        if (entry - sl > atr * 2.2) trigger = null;
      }
      if (trigger) {
        var risk = Math.abs(sl - entry);
        var tps = buildTargets(m, trigger.side, risk);
        plan = {
          side: trigger.side,
          entry: U.round(entry, 2),
          sl: U.round(sl, 2),
          tps: tps,
          risk: U.round(risk, 2),
          rr: U.round(tps[1].r, 2),
          rr1: U.round(tps[0].r, 2),
          rr3: U.round(tps[2].r, 2),
          reward: U.round(Math.abs(tps[1].price - entry), 2),
          stopPts: U.round(risk, 2),
          validUntil: candles[n - 1].time + XAU.CONFIG.timeframes[tfKey].seconds * 6
        };
      }
    }

    var mode = plan ? "setup" : b.side ? "waiting" : "neutral";
    var keyLabel = b.side === "BEARISH" ? "Lower high" : b.side === "BULLISH" ? "Higher low" : "Key level";
    var allowed = b.side === "BEARISH" ? "Sells only" : b.side === "BULLISH" ? "Buys only" : "No trades";
    var flipText;
    if (!b.side) flipText = "Wait for a clean HH + HL or LH + LL";
    else if (b.pending) {
      var back = b.side === "BULLISH" ? price > b.pending.level : price < b.pending.level;
      flipText = back
        ? "Close back " + (b.side === "BULLISH" ? "above " : "below ") + U.fmtPrice(b.pending.level) + " clears the warning"
        : "Under question — awaiting a " + (b.pending.to === "BULLISH" ? "higher low" : "lower high");
    } else if (b.side === "BEARISH") {
      flipText = "Close > " + U.fmtPrice(b.keyLevel) + " + higher low holds";
    } else {
      flipText = "Close < " + U.fmtPrice(b.keyLevel) + " + lower high forms";
    }

    var reasons = [];
    if (!b.side) {
      reasons.push({ text: "No clean 1H structure — neither higher highs + higher lows nor lower highs + lower lows" });
      reasons.push({ text: "No trades are taken until a bias is established" });
    } else {
      if (flipped) {
        reasons.push({ text: "Structure flipped to " + b.side.toLowerCase() + " — close beyond the old key level plus a confirmed " + keyLabel.toLowerCase() + " at " + U.fmtPrice(b.keyLevel) });
      } else {
        reasons.push({ text: "Bias " + b.side.toLowerCase() + " — " + (b.side === "BEARISH" ? "lower highs + lower lows" : "higher highs + higher lows") });
      }
      reasons.push({ text: keyLabel + " " + U.fmtPrice(b.keyLevel) + " is the level that would question the bias" });
      if (plan) {
        reasons.push({ text: trigger.label + " at " + U.fmtPrice(isFinite(trigger.level) ? trigger.level : b.keyLevel) + " — " + allowed.toLowerCase() });
        reasons.push({ text: "Stop " + U.fmtPrice(plan.sl) + " beyond structure · targets " + plan.rr1.toFixed(1) + "R / " + plan.rr.toFixed(1) + "R / " + plan.rr3.toFixed(1) + "R" });
      } else if (b.pending) {
        var backIntra = b.side === "BULLISH" ? price > b.pending.level : price < b.pending.level;
        reasons.push({ text: backIntra
          ? "The last 1H close was beyond the key level — a close back " + (b.side === "BULLISH" ? "above" : "below") + " it clears the warning"
          : "Price closed beyond the key level — no new trade until the flip sequence confirms" });
        reasons.push({ text: flipText });
      } else if (b.side === "BEARISH") {
        reasons.push({ text: "Waiting for a break below the 20-bar low" + (isFinite(rangeLow) ? " at " + U.fmtPrice(rangeLow) : "") + ", or a retest of the lower high at " + U.fmtPrice(b.keyLevel) });
        reasons.push({ text: "No counter-trend buys while the bias is bearish" });
      } else {
        reasons.push({ text: "Waiting for a break above the 20-bar high" + (isFinite(rangeHigh) ? " at " + U.fmtPrice(rangeHigh) : "") + ", or a retest of the higher low at " + U.fmtPrice(b.keyLevel) });
        reasons.push({ text: "No counter-trend sells while the bias is bullish" });
      }
    }

    var waitText = "";
    if (!plan && b.side && !b.pending) {
      waitText = b.side === "BULLISH"
        ? "Bullish bias — waiting for a break above " + (isFinite(rangeHigh) ? U.fmtPrice(rangeHigh) : "the 20-bar high") + " or a higher-low retest"
        : "Bearish bias — waiting for a break below " + (isFinite(rangeLow) ? U.fmtPrice(rangeLow) : "the 20-bar low") + " or a lower-high retest";
    }

    return {
      tf: tfKey,
      price: price,
      atr: atr,
      waitText: waitText,
      side: plan ? plan.side : (b.side === "BEARISH" ? "SELL" : b.side === "BULLISH" ? "BUY" : "NEUTRAL"),
      mode: mode,
      setupLabel: trigger ? trigger.label : "",
      bias: {
        side: b.side,
        keyLevel: b.keyLevel,
        keyLabel: keyLabel,
        allowed: allowed,
        flipText: flipText,
        pending: b.pending,
        state: b.pending ? "questioned" : b.side ? "intact" : "none",
        lastHigh: hi1,
        lastLow: lo1,
        higherHigh: higherHigh, higherLow: higherLow,
        lowerHigh: lowerHigh, lowerLow: lowerLow,
        since: b.since,
        flippedAt: b.flippedAt,
        flipped: flipped
      },
      biasState: b,
      plan: plan,
      reasons: reasons.slice(0, 4),
      channel: m.channel,
      structure: m.structure,
      levels: m.levels,
      indicators: m.indicators,
      day: m.day,
      at: Date.now()
    };
  }

  XAU.signals = {
    evaluate: evaluate,
    buildTargets: buildTargets
  };

  function seedBias(pivots, atr, upto) {
    var highs = [], lows = [];
    for (var h = 0; h < pivots.highs.length; h++) if (pivots.highs[h].index <= upto - 3) highs.push(pivots.highs[h]);
    for (var l = 0; l < pivots.lows.length; l++) if (pivots.lows[l].index <= upto - 3) lows.push(pivots.lows[l]);
    var hi1 = lastOf(highs), hi2 = prevOf(highs);
    var lo1 = lastOf(lows), lo2 = prevOf(lows);
    if (!hi1 || !hi2 || !lo1 || !lo2) return null;
    if (hi1.price > hi2.price + atr * 0.05 && lo1.price > lo2.price + atr * 0.05) {
      return {
        side: "BULLISH", keyLevel: lo1.price, keyIndex: lo1.index, keyTime: lo1.time,
        pending: null, flippedAt: 0, since: 0
      };
    }
    if (hi1.price < hi2.price - atr * 0.05 && lo1.price < lo2.price - atr * 0.05) {
      return {
        side: "BEARISH", keyLevel: hi1.price, keyIndex: hi1.index, keyTime: hi1.time,
        pending: null, flippedAt: 0, since: 0
      };
    }
    return null;
  }

  function bootstrapBias(candles, pivots, atr) {
    var n = candles.length;
    var start = Math.max(6, n - 150);
    var b = seedBias(pivots, atr, start);
    for (var i = start; i <= n; i++) {
      var hs = [], ls = [];
      for (var h = 0; h < pivots.highs.length; h++) if (pivots.highs[h].index <= i - 3) hs.push(pivots.highs[h]);
      for (var l = 0; l < pivots.lows.length; l++) if (pivots.lows[l].index <= i - 3) ls.push(pivots.lows[l]);
      var slice = candles.slice(0, i);
      var m = {
        candles: slice, n: i, price: slice[i - 1].close, atr: atr,
        pivots: { highs: hs, lows: ls }, channel: null, levels: [], day: null,
        indicators: {}, structure: {}
      };
      var r = evaluate(m, "H1", b, { bootstrap: true });
      b = r.biasState;
    }
    return b;
  }

  XAU.analyze = function (candles, tfKey, bias) {
    var market = XAU.analysis.build(candles);
    if (!market) return null;
    if (!bias) bias = bootstrapBias(candles, market.pivots, market.atr);
    var result = XAU.signals.evaluate(market, tfKey, bias);
    result.market = market;
    return result;
  };
})();
