(function () {
  function sma(values, period) {
    var out = new Array(values.length).fill(null);
    var sum = 0;
    for (var i = 0; i < values.length; i++) {
      sum += values[i];
      if (i >= period) sum -= values[i - period];
      if (i >= period - 1) out[i] = sum / period;
    }
    return out;
  }

  function ema(values, period) {
    var out = new Array(values.length).fill(null);
    if (values.length < period) return out;
    var k = 2 / (period + 1);
    var seed = 0;
    for (var i = 0; i < period; i++) seed += values[i];
    var prev = seed / period;
    out[period - 1] = prev;
    for (var j = period; j < values.length; j++) {
      prev = values[j] * k + prev * (1 - k);
      out[j] = prev;
    }
    return out;
  }

  function rsi(values, period) {
    var p = period || 14;
    var out = new Array(values.length).fill(null);
    if (values.length <= p) return out;
    var gain = 0, loss = 0;
    for (var i = 1; i <= p; i++) {
      var d = values[i] - values[i - 1];
      if (d >= 0) gain += d; else loss -= d;
    }
    var ag = gain / p, al = loss / p;
    out[p] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    for (var j = p + 1; j < values.length; j++) {
      var ch = values[j] - values[j - 1];
      var g = ch > 0 ? ch : 0;
      var l = ch < 0 ? -ch : 0;
      ag = (ag * (p - 1) + g) / p;
      al = (al * (p - 1) + l) / p;
      out[j] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    }
    return out;
  }

  function macd(values, fast, slow, signalPeriod) {
    var f = fast || 12, s = slow || 26, sigP = signalPeriod || 9;
    var emaFast = ema(values, f);
    var emaSlow = ema(values, s);
    var line = values.map(function (_, i) {
      if (emaFast[i] === null || emaSlow[i] === null) return null;
      return emaFast[i] - emaSlow[i];
    });
    var compact = [];
    var startIdx = -1;
    for (var i = 0; i < line.length; i++) {
      if (line[i] === null) continue;
      if (startIdx === -1) startIdx = i;
      compact.push(line[i]);
    }
    var sigCompact = ema(compact, sigP);
    var signal = new Array(values.length).fill(null);
    for (var j = 0; j < sigCompact.length; j++) {
      if (sigCompact[j] === null) continue;
      signal[startIdx + j] = sigCompact[j];
    }
    var hist = values.map(function (_, k) {
      if (line[k] === null || signal[k] === null) return null;
      return line[k] - signal[k];
    });
    return { macd: line, signal: signal, hist: hist };
  }

  function trueRanges(candles) {
    var tr = new Array(candles.length).fill(null);
    for (var i = 1; i < candles.length; i++) {
      var c = candles[i], p = candles[i - 1];
      tr[i] = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    }
    return tr;
  }

  function atr(candles, period) {
    var p = period || 14;
    var tr = trueRanges(candles);
    var out = new Array(candles.length).fill(null);
    var sum = 0;
    for (var i = 1; i < candles.length; i++) {
      sum += tr[i];
      if (i >= p) sum -= tr[i - p];
      if (i >= p) out[i] = sum / p;
    }
    return out;
  }

  function stdev(values) {
    if (values.length < 2) return 0;
    var m = values.reduce(function (a, b) { return a + b; }, 0) / values.length;
    var v = values.reduce(function (a, b) { return a + (b - m) * (b - m); }, 0) / (values.length - 1);
    return Math.sqrt(v);
  }

  function swings(candles, lookback) {
    var k = lookback || 2;
    var highs = [], lows = [];
    for (var i = k; i < candles.length - k; i++) {
      var isHigh = true, isLow = true;
      for (var j = i - k; j <= i + k; j++) {
        if (j === i) continue;
        if (candles[j].high >= candles[i].high) isHigh = false;
        if (candles[j].low <= candles[i].low) isLow = false;
      }
      if (isHigh) highs.push({ index: i, price: candles[i].high, time: candles[i].time });
      if (isLow) lows.push({ index: i, price: candles[i].low, time: candles[i].time });
    }
    return { highs: highs, lows: lows };
  }

  function linreg(points) {
    var n = points.length;
    if (n < 2) return { slope: 0, intercept: points.length ? points[0].y : 0, r2: 0 };
    var sx = 0, sy = 0, sxy = 0, sxx = 0, syy = 0;
    for (var i = 0; i < n; i++) {
      var x = points[i].x, y = points[i].y;
      sx += x; sy += y; sxy += x * y; sxx += x * x; syy += y * y;
    }
    var denom = n * sxx - sx * sx;
    if (Math.abs(denom) < 1e-9) return { slope: 0, intercept: sy / n, r2: 0 };
    var slope = (n * sxy - sx * sy) / denom;
    var intercept = (sy - slope * sx) / n;
    var meanY = sy / n;
    var ssTot = syy - n * meanY * meanY;
    var ssRes = 0;
    for (var j = 0; j < n; j++) {
      var pred = slope * points[j].x + intercept;
      ssRes += Math.pow(points[j].y - pred, 2);
    }
    return { slope: slope, intercept: intercept, r2: ssTot > 1e-9 ? Math.max(0, 1 - ssRes / ssTot) : 0 };
  }

  function last(arr) {
    for (var i = arr.length - 1; i >= 0; i--) {
      if (arr[i] !== null && arr[i] !== undefined && isFinite(arr[i])) return arr[i];
    }
    return null;
  }

  function at(arr, idx) {
    if (idx < 0) idx = arr.length + idx;
    var v = arr[idx];
    return v === null || v === undefined || !isFinite(v) ? null : v;
  }

  XAU.indicators = {
    sma: sma, ema: ema, rsi: rsi, macd: macd, atr: atr,
    stdev: stdev, swings: swings, linreg: linreg, last: last, at: at
  };
})();
