(function () {
  var I = XAU.indicators;
  var U = XAU.utils;

  function dedupePivots(list, minGap) {
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var p = list[i];
      var prev = out[out.length - 1];
      if (prev && p.index - prev.index < minGap) {
        if (p.price > prev.price) out[out.length - 1] = p;
        continue;
      }
      out.push(p);
    }
    return out;
  }

  function detectStructure(pivots, price, atr) {
    var highs = pivots.highs.slice(-5);
    var lows = pivots.lows.slice(-5);
    var hh = false, hl = false, lh = false, ll = false;
    if (highs.length >= 2) {
      var a = highs[highs.length - 2].price, b = highs[highs.length - 1].price;
      hh = b > a + atr * 0.05;
      lh = b < a - atr * 0.05;
    }
    if (lows.length >= 2) {
      var c = lows[lows.length - 2].price, d = lows[lows.length - 1].price;
      hl = d > c + atr * 0.05;
      ll = d < c - atr * 0.05;
    }
    var label, bias = 0;
    if (hh && hl) { label = "Higher highs · higher lows"; bias = 1; }
    else if (lh && ll) { label = "Lower highs · lower lows"; bias = -1; }
    else if (hh && ll) { label = "Expanding range"; bias = 0; }
    else if (lh && hl) { label = "Contracting range"; bias = 0; }
    else if (hh || hl) { label = "Mildly bullish structure"; bias = 0.5; }
    else if (lh || ll) { label = "Mildly bearish structure"; bias = -0.5; }
    else { label = "Range / no clear structure"; bias = 0; }

    var bos = 0;
    var lastHigh = highs.length ? highs[highs.length - 1] : null;
    var lastLow = lows.length ? lows[lows.length - 1] : null;
    if (lastHigh && price > lastHigh.price + atr * 0.08) bos = 1;
    if (lastLow && price < lastLow.price - atr * 0.08) bos = -1;

    return {
      label: label,
      bias: bias,
      bos: bos,
      higherHighs: hh,
      higherLows: hl,
      lastHigh: lastHigh,
      lastLow: lastLow,
      highs: highs,
      lows: lows
    };
  }

  function fitLine(points, atrValue) {
    if (points.length < 2) return null;
    var reg = I.linreg(points.map(function (p) { return { x: p.index, y: p.price }; }));
    if (points.length >= 4) {
      var resid = points.map(function (p) {
        return { p: p, r: Math.abs(p.price - (reg.slope * p.index + reg.intercept)) };
      }).sort(function (a, b) { return b.r - a.r; });
      if (resid[0].r > atrValue * 2.2) {
        var keep = resid.slice(1).map(function (o) { return o.p; });
        reg = I.linreg(keep.map(function (p) { return { x: p.index, y: p.price }; }));
      }
    }
    return { slope: reg.slope, intercept: reg.intercept, r2: reg.r2 };
  }

  function countTouches(points, line, atrValue) {
    var tol = Math.max(atrValue * 0.4, 0.0004 * Math.abs(line.intercept || 1));
    var n = 0;
    for (var i = 0; i < points.length; i++) {
      var expected = line.slope * points[i].index + line.intercept;
      if (Math.abs(points[i].price - expected) <= tol) n++;
    }
    return n;
  }

  function detectChannel(pivots, candles, atrValue, futureBars) {
    var n = candles.length;
    var price = candles[n - 1].close;
    var from = Math.max(0, n - 190);
    var highs = pivots.highs.filter(function (p) { return p.index >= from; }).slice(-9);
    var lows = pivots.lows.filter(function (p) { return p.index >= from; }).slice(-9);
    if (highs.length < 3 || lows.length < 3) return null;

    var upper = fitLine(highs, atrValue);
    var lower = fitLine(lows, atrValue);
    if (!upper || !lower) return null;

    var startIndex = Math.max(0, Math.min(highs[0].index, lows[0].index) - 12);
    var endIndex = n - 1 + (futureBars || 16);
    var span = Math.max(1, endIndex - startIndex);
    var upperNow = upper.slope * (n - 1) + upper.intercept;
    var lowerNow = lower.slope * (n - 1) + lower.intercept;
    var width = upperNow - lowerNow;
    if (width <= 0) return null;

    var upperTouches = countTouches(highs, upper, atrValue);
    var lowerTouches = countTouches(lows, lower, atrValue);
    var avgSlope = (upper.slope + lower.slope) / 2;
    var slopeNorm = avgSlope / Math.max(atrValue, 0.01);
    var parallelDiff = Math.abs(upper.slope - lower.slope) / (Math.abs(avgSlope) + atrValue * 0.012);
    var r2 = (Math.max(0, upper.r2) + Math.max(0, lower.r2)) / 2;
    var quality = U.clamp(Math.round((r2 * 0.55 + Math.min(6, upperTouches + lowerTouches) / 12 * 0.2 + (parallelDiff < 0.9 ? 0.25 : 0.05)) * 100), 0, 100);

    var type;
    if (slopeNorm > 0.028 && upper.slope > 0 && lower.slope > 0) type = "ascending";
    else if (slopeNorm < -0.028 && upper.slope < 0 && lower.slope < 0) type = "descending";
    else if (parallelDiff > 1.25) type = width > Math.abs(upperNow - lowerNow) * 0.9 ? "expanding" : "contracting";
    else type = "horizontal";

    var position = (price - lowerNow) / width;
    var mid = { slope: avgSlope, intercept: (upper.intercept + lower.intercept) / 2 };

    return {
      upper: upper,
      lower: lower,
      mid: mid,
      type: type,
      slopeNorm: slopeNorm,
      parallel: parallelDiff < 0.9,
      quality: quality,
      qualified: quality >= 38 && width < atrValue * 14,
      width: width,
      widthAtr: width / Math.max(atrValue, 0.01),
      position: position,
      upperTouches: upperTouches,
      lowerTouches: lowerTouches,
      startIndex: startIndex,
      endIndex: endIndex,
      upperStart: upper.slope * startIndex + upper.intercept,
      upperEnd: upper.slope * endIndex + upper.intercept,
      lowerStart: lower.slope * startIndex + lower.intercept,
      lowerEnd: lower.slope * endIndex + lower.intercept
    };
  }

  function detectLevels(pivots, price, atrValue, n) {
    var pts = pivots.highs.concat(pivots.lows).filter(function (p) {
      return p.index > n - 200;
    });
    if (!pts.length) return [];
    pts.sort(function (a, b) { return a.price - b.price; });
    var tol = Math.max(atrValue * 0.7, price * 0.0008);
    var clusters = [];
    var current = null;
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (!current || Math.abs(p.price - current.price) > tol) {
        current = { price: p.price, sumW: 1, count: 1, lastIndex: p.index, touches: 1 };
        clusters.push(current);
      } else {
        var w = 1 + p.index / n;
        current.price = (current.price * current.sumW + p.price * w) / (current.sumW + w);
        current.sumW += w;
        current.touches += 1;
        current.lastIndex = Math.max(current.lastIndex, p.index);
      }
    }

    var scored = clusters.filter(function (c) { return c.touches >= 2; }).map(function (c) {
      var recency = c.lastIndex / n;
      var distAtr = Math.abs(c.price - price) / Math.max(atrValue, 0.01);
      var score = c.touches * 2 + recency * 3 - Math.min(distAtr, 12) * 0.12;
      return {
        price: c.price,
        touches: c.touches,
        strength: Math.round(U.clamp(score / 9 * 100, 8, 99)),
        type: c.price >= price ? "resistance" : "support",
        distance: Math.abs(c.price - price),
        recency: recency
      };
    }).sort(function (a, b) { return b.strength - a.strength; });

    var deadZone = atrValue * 0.15;
    scored = scored.filter(function (l) { return Math.abs(l.price - price) > deadZone; });
    var above = scored.filter(function (l) { return l.price >= price; })
      .sort(function (a, b) { return a.price - b.price; }).slice(0, 3);
    var below = scored.filter(function (l) { return l.price < price; })
      .sort(function (a, b) { return b.price - a.price; }).slice(0, 3);

    return below.concat(above).sort(function (a, b) { return b.price - a.price; });
  }

  function dayStats(candles, price) {
    var n = candles.length;
    var now = Date.now() / 1000;
    var d = new Date();
    var midnight = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) / 1000;
    var startIdx = -1;
    for (var i = n - 1; i >= 0; i--) {
      if (candles[i].time < midnight) break;
      startIdx = i;
    }
    var sliceStart = startIdx >= 0 ? startIdx : Math.max(0, n - 24);
    var open = candles[sliceStart].open;
    var high = -Infinity, low = Infinity;
    for (var j = sliceStart; j < n; j++) {
      if (candles[j].high > high) high = candles[j].high;
      if (candles[j].low < low) low = candles[j].low;
    }
    var prevClose = sliceStart > 0 ? candles[sliceStart - 1].close : open;
    var lastPrice = isFinite(price) ? price : candles[n - 1].close;
    var change = lastPrice - prevClose;
    return {
      open: open,
      high: Math.max(high, lastPrice),
      low: Math.min(low, lastPrice),
      prevClose: prevClose,
      change: change,
      changePct: prevClose ? (change / prevClose) * 100 : 0,
      spanHours: (now - candles[sliceStart].time) / 3600
    };
  }

  function build(candles) {
    if (!candles || candles.length < 60) return null;
    var n = candles.length;
    var closes = candles.map(function (c) { return c.close; });
    var ema9 = I.ema(closes, 9);
    var ema21 = I.ema(closes, 21);
    var sma50 = I.sma(closes, 50);
    var rsi = I.rsi(closes, 14);
    var macd = I.macd(closes, 12, 26, 9);
    var atrSeries = I.atr(candles, 14);
    var atrValue = I.last(atrSeries) || closes[n - 1] * 0.002;

    var pivots = I.swings(candles, 2);
    pivots.highs = dedupePivots(pivots.highs, 3);
    pivots.lows = dedupePivots(pivots.lows, 3);

    var price = closes[n - 1];
    var structure = detectStructure(pivots, price, atrValue);
    var channel = detectChannel(pivots, candles, atrValue, 22);
    var levels = detectLevels(pivots, price, atrValue, n);

    return {
      candles: candles,
      n: n,
      price: price,
      atr: atrValue,
      atrSeries: atrSeries,
      ema9: ema9,
      ema21: ema21,
      sma50: sma50,
      rsi: rsi,
      macd: macd,
      pivots: pivots,
      structure: structure,
      channel: channel,
      levels: levels,
      day: dayStats(candles, price),
      indicators: {
        ema9: I.last(ema9),
        ema21: I.last(ema21),
        sma50: I.last(sma50),
        rsi: I.last(rsi),
        macd: I.last(macd.macd),
        signal: I.last(macd.signal),
        hist: I.last(macd.hist),
        histPrev: I.at(macd.hist, n - 2),
        ema9Prev: I.at(ema9, n - 4),
        ema21Prev: I.at(ema21, n - 6),
        rsiPrev: I.at(rsi, n - 4)
      }
    };
  }

  XAU.analysis = { build: build, detectLevels: detectLevels, detectChannel: detectChannel };
})();
