(function () {
  var P = XAU.CONFIG.storagePrefix;

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function storeGet(key, fallback) {
    try {
      var raw = localStorage.getItem(P + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (e) { return fallback; }
  }

  function storeSet(key, value) {
    try { localStorage.setItem(P + key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  }

  function storeDel(key) {
    try { localStorage.removeItem(P + key); } catch (e) {}
  }

  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
  function sum(a) { return a.reduce(function (s, v) { return s + v; }, 0); }
  function avg(a) { return a.length ? sum(a) / a.length : 0; }
  function round(v, d) { var m = Math.pow(10, d == null ? 2 : d); return Math.round(v * m) / m; }
  function toNum(v, fb) { var n = parseFloat(v); return isFinite(n) ? n : (fb == null ? 0 : fb); }

  function fmtPrice(v, d) {
    if (v === null || v === undefined || !isFinite(v)) return "—";
    return Number(v).toLocaleString("en-US", { minimumFractionDigits: d == null ? 2 : d, maximumFractionDigits: d == null ? 2 : d });
  }

  function fmtSigned(v, d) {
    if (!isFinite(v)) return "—";
    return (v > 0 ? "+" : v < 0 ? "−" : "") + fmtPrice(Math.abs(v), d == null ? 2 : d);
  }

  function fmtMoney(v, d) {
    if (!isFinite(v)) return "—";
    return (v < 0 ? "−" : "") + "$" + fmtPrice(Math.abs(v), d == null ? 2 : d);
  }

  function fmtCompactMoney(v) {
    if (!isFinite(v)) return "—";
    var a = Math.abs(v);
    if (a >= 1e6) return (v < 0 ? "−" : "") + "$" + round(a / 1e6, 2) + "M";
    if (a >= 1e4) return (v < 0 ? "−" : "") + "$" + round(a / 1e3, 1) + "k";
    return fmtMoney(v, 2);
  }

  function fmtPct(v, d) {
    if (!isFinite(v)) return "—";
    return (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v).toFixed(d == null ? 2 : d) + "%";
  }

  function fmtR(v) {
    if (!isFinite(v)) return "—";
    return (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v).toFixed(2) + "R";
  }

  function pad(n) { return n < 10 ? "0" + n : "" + n; }

  function fmtTimeUTC(sec) {
    var d = new Date(sec * 1000);
    return pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes());
  }

  function fmtClockUTC(sec) {
    var d = new Date(sec * 1000);
    return pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + ":" + pad(d.getUTCSeconds());
  }

  function fmtHM(sec) {
    var d = new Date(sec * 1000);
    return pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + " UTC";
  }

  function fmtDateTime(sec) {
    var d = new Date(sec * 1000);
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return d.getUTCDate() + " " + months[d.getUTCMonth()] + " · " + pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + " UTC";
  }

  function fmtDateShort(sec) {
    var d = new Date(sec * 1000);
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return d.getUTCDate() + " " + months[d.getUTCMonth()];
  }

  function timeAgo(sec) {
    var diff = Math.max(0, Math.floor(Date.now() / 1000 - sec));
    if (diff < 10) return "just now";
    if (diff < 60) return diff + "s ago";
    if (diff < 3600) return Math.floor(diff / 60) + "m ago";
    if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
    return Math.floor(diff / 86400) + "d ago";
  }

  function durationShort(ms) {
    var s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return s + "s";
    var m = Math.floor(s / 60);
    if (m < 60) return m + "m " + pad(s % 60) + "s";
    return Math.floor(m / 60) + "h " + pad(m % 60) + "m";
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, wait);
    };
  }

  function throttle(fn, wait) {
    var last = 0, t = null, pending = null;
    return function () {
      var now = Date.now(), self = this, args = arguments;
      var remain = wait - (now - last);
      if (remain <= 0) {
        if (t) { clearTimeout(t); t = null; }
        last = now;
        fn.apply(self, args);
      } else {
        pending = args;
        if (!t) {
          t = setTimeout(function () {
            t = null; last = Date.now();
            fn.apply(self, pending);
          }, remain);
        }
      }
    };
  }

  function rafThrottle(fn) {
    var queued = false;
    return function () {
      if (queued) return;
      queued = true;
      requestAnimationFrame(function () { queued = false; fn(); });
    };
  }

  function marketState(date) {
    var d = date || new Date();
    var day = d.getUTCDay();
    var hour = d.getUTCHours();
    var mins = d.getUTCMinutes();
    var open;
    if (day === 6) open = false;
    else if (day === 0) open = hour >= 22;
    else if (day === 5) open = hour < 21;
    else open = !(hour === 21);
    var session;
    if (!open) session = "Market closed";
    else if (hour >= 22 || hour < 2) session = "Sydney / Tokyo";
    else if (hour < 7) session = "Tokyo";
    else if (hour < 12) session = "London";
    else if (hour < 16) session = "London · New York";
    else if (hour < 21) session = "New York";
    else session = "Market closed";
    return {
      open: open,
      session: session,
      label: open ? "Open · " + session : "Closed · reopens Sun 22:00 UTC",
      minuteOfDay: hour * 60 + mins
    };
  }

  var audioCtx = null;
  function unlockAudio() {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!audioCtx) { try { audioCtx = new AC(); } catch (e) { return; } }
    if (audioCtx.state === "suspended") audioCtx.resume().catch(function () {});
  }

  function beep(kind) {
    unlockAudio();
    if (!audioCtx) return;
    var now = audioCtx.currentTime;
    var seqs = {
      buy: [523.25, 659.25, 783.99],
      sell: [659.25, 523.25, 392.0],
      neutral: [587.33, 587.33],
      alert: [880, 1174.66]
    };
    var notes = seqs[kind] || seqs.alert;
    notes.forEach(function (freq, i) {
      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now + i * 0.11);
      gain.gain.setValueAtTime(0.0001, now + i * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.07, now + i * 0.11 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.11 + 0.18);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(now + i * 0.11);
      osc.stop(now + i * 0.11 + 0.2);
    });
  }

  function notify(title, body, tag) {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    try {
      new Notification(title, { body: body, tag: tag || "xau-signal", silent: false });
    } catch (e) {}
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        resolve();
      } catch (e) { reject(e); }
    });
  }

  XAU.utils = {
    $: $, $$: $$,
    storeGet: storeGet, storeSet: storeSet, storeDel: storeDel,
    clamp: clamp, sum: sum, avg: avg, round: round, toNum: toNum,
    fmtPrice: fmtPrice, fmtSigned: fmtSigned, fmtMoney: fmtMoney,
    fmtCompactMoney: fmtCompactMoney, fmtPct: fmtPct, fmtR: fmtR,
    fmtTimeUTC: fmtTimeUTC, fmtClockUTC: fmtClockUTC, fmtHM: fmtHM, fmtDateTime: fmtDateTime,
    fmtDateShort: fmtDateShort, timeAgo: timeAgo, durationShort: durationShort,
    escapeHtml: escapeHtml, uid: uid,
    debounce: debounce, throttle: throttle, rafThrottle: rafThrottle,
    marketState: marketState,
    beep: beep, unlockAudio: unlockAudio, notify: notify, copyText: copyText,
    pad: pad
  };
})();
