(function () {
  var U = XAU.utils;
  var LWC = window.LightweightCharts;

  function ChartEngine(host, overlay) {
    this.host = host;
    this.overlay = overlay;
    this.chart = null;
    this.candleSeries = null;
    this.ema9 = null;
    this.ema21 = null;
    this.sma50 = null;
    this.chUpper = null;
    this.chLower = null;
    this.chMid = null;
    this.candles = [];
    this.market = null;
    this.plan = null;
    this.futureBars = 20;
    this.overlays = { channels: true, levels: true, setup: true, emas: true };
    this.priceLines = [];
    this.timeList = [];
    this.candleByTime = {};
    this.el = {};
    this.lastRange = null;
    this.initialized = false;
    this.srRows = [];
  }

  ChartEngine.prototype.init = function () {
    var self = this;
    if (!LWC) throw new Error("Lightweight Charts failed to load");

    this.chart = LWC.createChart(this.host, {
      autoSize: true,
      layout: {
        background: { type: "solid", color: "#090b10" },
        textColor: "#75808f",
        fontSize: 11,
        fontFamily: "Inter, -apple-system, Segoe UI, Roboto, sans-serif"
      },
      grid: {
        vertLines: { color: "rgba(28, 34, 48, 0.55)" },
        horzLines: { color: "rgba(28, 34, 48, 0.55)" }
      },
      crosshair: {
        mode: LWC.CrosshairMode.Normal,
        vertLine: { color: "rgba(160, 175, 195, 0.35)", width: 1, style: 2, labelBackgroundColor: "#1b2432" },
        horzLine: { color: "rgba(160, 175, 195, 0.35)", width: 1, style: 2, labelBackgroundColor: "#1b2432" }
      },
      rightPriceScale: {
        borderColor: "#1a202b",
        scaleMargins: { top: 0.13, bottom: 0.12 },
        entireTextOnly: true
      },
      timeScale: {
        borderColor: "#1a202b",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 7,
        barSpacing: 7,
        minBarSpacing: 2,
        tickMarkFormatter: function (time) {
          var d = new Date(time * 1000);
          if (d.getUTCHours() === 0 && d.getUTCMinutes() === 0) return U.fmtDateShort(time);
          return U.fmtTimeUTC(time);
        }
      },
      localization: {
        priceFormatter: function (p) { return p.toFixed(2); },
        timeFormatter: function (time) {
          var d = new Date(time * 1000);
          return U.fmtDateShort(time) + " " + U.pad(d.getUTCHours()) + ":" + U.pad(d.getUTCMinutes());
        }
      },
      watermark: {
        visible: true,
        fontSize: 46,
        fontFamily: "Inter, sans-serif",
        color: "rgba(232, 237, 245, 0.028)",
        text: "XAUUSD"
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true }
    });

    this.candleSeries = this.chart.addCandlestickSeries({
      upColor: "#16c784",
      downColor: "#f6465d",
      borderVisible: false,
      borderUpColor: "#16c784",
      borderDownColor: "#f6465d",
      wickUpColor: "rgba(22, 199, 132, 0.85)",
      wickDownColor: "rgba(246, 70, 93, 0.85)",
      priceLineVisible: false,
      lastValueVisible: true,
      priceFormat: { type: "price", precision: 2, minMove: 0.01 }
    });

    this.ema9 = this.makeLine("#f0c052", 1, false);
    this.ema21 = this.makeLine("#4a9eff", 1, false);
    this.sma50 = this.makeLine("#9b8cff", 1, false);
    this.chUpper = this.makeLine("rgba(240, 192, 82, 0.85)", 1, true);
    this.chLower = this.makeLine("rgba(240, 192, 82, 0.85)", 1, true);
    this.chMid = this.makeLine("rgba(240, 192, 82, 0.35)", 1, true);
    [this.chUpper, this.chLower, this.chMid].forEach(function (s) {
      s.applyOptions({ autoscaleInfoProvider: function () { return null; } });
    });

    this.planBounds = null;
    this.candleSeries.applyOptions({
      autoscaleInfoProvider: function (original) {
        var res = original();
        if (!res || !res.priceRange) return res;
        var b = self.planBounds;
        if (!b) return res;
        var pr = res.priceRange;
        var span = Math.max(0.5, pr.maxValue - pr.minValue);
        var pad = span * 0.025;
        return {
          priceRange: {
            minValue: Math.min(pr.minValue, b.min - pad),
            maxValue: Math.max(pr.maxValue, b.max + pad)
          },
          margins: res.margins
        };
      }
    });

    this.buildOverlay();
    this.buildTooltip();

    this.chart.timeScale().subscribeVisibleLogicalRangeChange(function (range) {
      if (range) self.lastRange = range;
      self.scheduleOverlay();
    });
    this.chart.subscribeCrosshairMove(function (param) { self.onCrosshair(param); });

    ["wheel", "pointerdown", "pointerup", "pointermove"].forEach(function (evt) {
      self.host.addEventListener(evt, function () { self.scheduleOverlay(); }, { passive: true });
    });

    if (window.ResizeObserver) {
      this.ro = new ResizeObserver(function () { self.scheduleOverlay(); });
      this.ro.observe(this.host);
    }

    this.overlayTimer = setInterval(function () { self.renderOverlay(); }, 250);
    this.initialized = true;
  };

  ChartEngine.prototype.makeLine = function (color, width, dashed) {
    return this.chart.addLineSeries({
      color: color,
      lineWidth: width,
      lineStyle: dashed ? LWC.LineStyle.Dashed : LWC.LineStyle.Solid,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false
    });
  };

  ChartEngine.prototype.buildOverlay = function () {
    var o = this.overlay;
    o.innerHTML = "";
    function mk(cls, parent) {
      var d = document.createElement("div");
      d.className = cls;
      d.style.display = "none";
      (parent || o).appendChild(d);
      return d;
    }

    this.el.tpBox = mk("rrbox rrbox--tp");
    this.el.slBox = mk("rrbox rrbox--sl");

    this.el.entryLine = mk("rrline rrline--entry");
    this.el.slLine = mk("rrline rrline--sl");
    this.el.tpLines = [mk("rrline rrline--tp"), mk("rrline rrline--tp rrline--tp2"), mk("rrline rrline--tp rrline--tp3")];

    this.el.tags = {
      entry: mk("rrtag rrtag--entry"),
      sl: mk("rrtag rrtag--sl"),
      tp: [mk("rrtag rrtag--tp"), mk("rrtag rrtag--tp rrtag--tp2"), mk("rrtag rrtag--tp rrtag--tp3")]
    };

    this.srRows = [];
    for (var i = 0; i < 4; i++) {
      var row = mk("rrline srline");
      var tag = mk("srtag");
      this.srRows.push({ line: row, tag: tag });
    }
  };

  ChartEngine.prototype.buildTooltip = function () {
    var tip = document.createElement("div");
    tip.className = "chart-tip";
    this.host.appendChild(tip);
    this.tooltip = tip;
  };

  ChartEngine.prototype.onCrosshair = function (param) {
    var tip = this.tooltip;
    if (!tip) return;
    if (!param || !param.time || !param.point || param.point.x < 0 || param.point.y < 0) {
      tip.classList.remove("is-on");
      return;
    }
    var c = this.candleByTime[param.time];
    if (!c) { tip.classList.remove("is-on"); return; }
    var dirClass = c.close >= c.open ? "t-up" : "t-down";
    tip.innerHTML =
      '<b>' + U.fmtDateTime(param.time) + '</b><br>' +
      'O <b>' + U.fmtPrice(c.open) + '</b> · H <b>' + U.fmtPrice(c.high) + '</b><br>' +
      'L <b>' + U.fmtPrice(c.low) + '</b> · C <b class="' + dirClass + '">' + U.fmtPrice(c.close) + '</b>';
    var hostW = this.host.clientWidth;
    var left = param.point.x + 16;
    if (left + 190 > hostW) left = Math.max(6, param.point.x - 206);
    var top = Math.min(this.host.clientHeight - 80, Math.max(6, param.point.y + 16));
    tip.style.left = left + "px";
    tip.style.top = top + "px";
    tip.classList.add("is-on");
  };

  ChartEngine.prototype.setData = function (candles, tfKey, opts) {
    opts = opts || {};
    var t = XAU.CONFIG.timeframes[tfKey];
    var future = XAU.CONFIG.futureBars[tfKey] || 16;
    this.futureBars = future;
    this.tfKey = tfKey;
    var prevRange = this.lastRange;
    var prevN = this.candles.length;
    var prevLast = prevN ? this.candles[prevN - 1].time : 0;

    var clean = [];
    var seen = {};
    for (var i = 0; i < candles.length; i++) {
      var c = candles[i];
      if (!isFinite(c.time) || seen[c.time]) continue;
      seen[c.time] = 1;
      clean.push({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close });
    }
    clean.sort(function (a, b) { return a.time - b.time; });
    this.candles = clean;
    this.candleByTime = {};
    for (var j = 0; j < clean.length; j++) this.candleByTime[clean[j].time] = clean[j];
    this.timeList = clean.map(function (c) { return c.time; });

    this.candleSeries.setData(clean);

    var st = this.chart.timeScale();
    st.applyOptions({ rightOffset: future + 1 });
    if (opts.fit || !prevRange || !prevN) {
      var from = Math.max(0, clean.length - this.visibleCount());
      st.setVisibleLogicalRange({ from: from - 2, to: clean.length + future - 2 });
    } else {
      var newN = clean.length;
      var delta = newN - prevN;
      var span = prevRange.to - prevRange.from;
      var atRight = prevRange.to >= prevN - 1;
      if (newN !== prevN || (clean.length && prevLast !== clean[clean.length - 1].time && atRight)) {
        if (atRight) {
          st.setVisibleLogicalRange({ from: newN + future - span - 2, to: newN + future - 2 });
        } else if (delta) {
          st.setVisibleLogicalRange({ from: prevRange.from + delta, to: prevRange.to + delta });
        }
      }
    }
    this.lastRange = st.getVisibleLogicalRange();
    this.renderOverlay();
  };

  ChartEngine.prototype.setAnalysis = function (market) {
    if (!market) return;
    this.market = market;
    var times = this.timeList;

    function lineData(arr, fromIdx) {
      var out = [];
      for (var i = Math.max(0, fromIdx || 0); i < arr.length; i++) {
        if (arr[i] === null || arr[i] === undefined || !isFinite(arr[i])) continue;
        out.push({ time: times[i], value: arr[i] });
      }
      return out;
    }

    this.ema9.setData(this.overlays.emas ? lineData(market.ema9, 9) : []);
    this.ema21.setData(this.overlays.emas ? lineData(market.ema21, 21) : []);
    this.sma50.setData(this.overlays.emas ? lineData(market.sma50, 50) : []);

    var ch = market.channel;
    if (this.overlays.channels && ch && times.length) {
      var s = Math.max(0, ch.startIndex);
      var e = times.length - 1 + this.futureBars;
      var t0 = times[s];
      var lastIdx = times.length - 1;
      var endTime = times[lastIdx] + this.futureBars * XAU.CONFIG.timeframes[this.tfKey].seconds;
      this.chUpper.setData([
        { time: t0, value: ch.upper.slope * s + ch.upper.intercept },
        { time: endTime, value: ch.upper.slope * e + ch.upper.intercept }
      ]);
      this.chLower.setData([
        { time: t0, value: ch.lower.slope * s + ch.lower.intercept },
        { time: endTime, value: ch.lower.slope * e + ch.lower.intercept }
      ]);
      this.chMid.setData([
        { time: t0, value: ch.mid.slope * s + ch.mid.intercept },
        { time: endTime, value: ch.mid.slope * e + ch.mid.intercept }
      ]);
    } else {
      this.chUpper.setData([]);
      this.chLower.setData([]);
      this.chMid.setData([]);
    }
    this.updateLegend(market);
    this.renderOverlay();
  };

  ChartEngine.prototype.updateLegend = function (market) {
    var ind = market.indicators;
    var map = { lgEma9: ind.ema9, lgEma21: ind.ema21, lgSma50: ind.sma50 };
    Object.keys(map).forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.textContent = map[id] === null ? "—" : U.fmtPrice(map[id]);
    });
  };

  ChartEngine.prototype.setPlan = function (plan) {
    this.plan = plan;
    this.clearPriceLines();
    if (!plan || !this.overlays.setup) {
      this.planBounds = null;
      this.nudgeScale();
      this.renderOverlay();
      return;
    }

    this.planBounds = {
      min: Math.min(plan.sl, plan.entry, plan.tps[0].price, plan.tps[1].price, plan.tps[2].price),
      max: Math.max(plan.sl, plan.entry, plan.tps[0].price, plan.tps[1].price, plan.tps[2].price)
    };
    this.nudgeScale();
    var self = this;
    var cfg = [
      { price: plan.entry, color: "rgba(240, 192, 82, 0.9)", title: "ENTRY", style: LWC.LineStyle.Solid, width: 1 },
      { price: plan.sl, color: "rgba(246, 70, 93, 0.85)", title: "SL", style: LWC.LineStyle.Dashed, width: 1 },
      { price: plan.tps[0].price, color: "rgba(22, 199, 132, 0.75)", title: "TP1", style: LWC.LineStyle.Dotted, width: 1 },
      { price: plan.tps[1].price, color: "rgba(22, 199, 132, 0.55)", title: "TP2", style: LWC.LineStyle.Dotted, width: 1 },
      { price: plan.tps[2].price, color: "rgba(22, 199, 132, 0.4)", title: "TP3", style: LWC.LineStyle.Dotted, width: 1 }
    ];
    cfg.forEach(function (c) {
      var pl = self.candleSeries.createPriceLine({
        price: c.price,
        color: c.color,
        lineWidth: c.width,
        lineStyle: c.style,
        axisLabelVisible: false,
        title: c.title
      });
      self.priceLines.push(pl);
    });
    this.updateTags();
    this.renderOverlay();
  };

  ChartEngine.prototype.nudgeScale = function () {
    if (!this.candles.length) return;
    var last = this.candles[this.candles.length - 1];
    try {
      this.candleSeries.update(last);
      this.chart.priceScale("right").applyOptions({ autoScale: true });
    } catch (e) {}
    this.scheduleOverlay();
  };

  ChartEngine.prototype.clearPriceLines = function () {
    var self = this;
    this.priceLines.forEach(function (pl) {
      try { self.candleSeries.removePriceLine(pl); } catch (e) {}
    });
    this.priceLines = [];
  };

  ChartEngine.prototype.updateTags = function () {
    var plan = this.plan;
    var tags = this.el.tags;
    if (!plan) return;
    tags.entry.textContent = "ENTRY " + U.fmtPrice(plan.entry);
    tags.sl.textContent = "SL " + U.fmtPrice(plan.sl);
    for (var i = 0; i < 3; i++) {
      tags.tp[i].innerHTML = "TP" + (i + 1) + " " + U.fmtPrice(plan.tps[i].price) + "<em> · " + plan.tps[i].r.toFixed(2) + "R</em>";
    }
  };

  ChartEngine.prototype.setOverlays = function (ov) {
    this.overlays = ov;
    if (this.market) this.setAnalysis(this.market);
    this.setPlan(this.plan);
    this.renderOverlay();
  };

  ChartEngine.prototype.scheduleOverlay = function () {
    if (this.overlayRaf) return;
    var self = this;
    this.overlayRaf = requestAnimationFrame(function () {
      self.overlayRaf = null;
      self.renderOverlay();
    });
  };

  ChartEngine.prototype.setBox = function (box, yA, yB, x1, x2, paneH) {
    if (yA === null || yB === null || yA === undefined || yB === undefined) {
      box.style.display = "none";
      return false;
    }
    var top = Math.max(0, Math.min(yA, yB));
    var bottom = Math.min(paneH, Math.max(yA, yB));
    if (bottom - top < 1) { box.style.display = "none"; return false; }
    box.style.display = "block";
    box.style.left = x1 + "px";
    box.style.width = Math.max(0, x2 - x1) + "px";
    box.style.top = top + "px";
    box.style.height = bottom - top + "px";
    return true;
  };

  ChartEngine.prototype.setLineEl = function (el, y, x1, x2) {
    if (y === null || y === undefined || !isFinite(y)) { el.style.display = "none"; return; }
    el.style.display = "block";
    el.style.top = y + "px";
    el.style.left = x1 + "px";
    el.style.right = "auto";
    el.style.width = Math.max(0, x2 - x1) + "px";
    el.style.borderTopWidth = "1px";
  };

  ChartEngine.prototype.setTagEl = function (el, y, x, alignRight) {
    if (y === null || y === undefined || !isFinite(y)) { el.style.display = "none"; return; }
    el.style.display = "block";
    el.style.top = y + "px";
    el.style.left = x + "px";
    el.style.transform = alignRight ? "translate(-100%, -50%)" : "translate(0, -50%)";
  };

  ChartEngine.prototype.renderOverlay = function () {
    if (!this.initialized || !this.chart) return;
    var ts = this.chart.timeScale();
    var hostW = this.host.clientWidth;
    var hostH = this.host.clientHeight;
    var axisW = this.chart.priceScale("right").width();
    var axisH = ts.height();
    var paneH = hostH - axisH;
    if (paneH < 40 || hostW < 40) return;

    var priceAxisX = hostW - axisW - 5;
    var setup = this.plan && this.overlays.setup;
    var el = this.el;

    if (!setup || !this.candles.length) {
      el.tpBox.style.display = "none";
      el.slBox.style.display = "none";
      el.entryLine.style.display = "none";
      el.slLine.style.display = "none";
      el.tpLines.forEach(function (l) { l.style.display = "none"; });
      Object.keys(el.tags).forEach(function (k) {
        if (k === "tp") el.tags.tp.forEach(function (t) { t.style.display = "none"; });
        else el.tags[k].style.display = "none";
      });
    } else {
      var plan = this.plan;
      var entryIdx = this.candles.length - 1;
      var endIdx = entryIdx + this.futureBars;
      var x1 = ts.logicalToCoordinate(entryIdx);
      var x2 = ts.logicalToCoordinate(endIdx);
      if (x1 === null) x1 = priceAxisX - 200;
      if (x2 === null) x2 = priceAxisX;
      x1 = Math.max(0, Math.min(x1, priceAxisX));
      x2 = Math.max(x1 + 40, Math.min(x2, priceAxisX));

      var yEntry = this.candleSeries.priceToCoordinate(plan.entry);
      var ySl = this.candleSeries.priceToCoordinate(plan.sl);
      var yTps = plan.tps.map(function (t, i) { return this.candleSeries.priceToCoordinate(t.price); }, this);

      if (yEntry !== null && ySl !== null) {
        this.setBox(el.slBox, yEntry, ySl, x1, x2, paneH);
        this.setBox(el.tpBox, yEntry, yTps[2], x1, x2, paneH);
        this.setLineEl(el.entryLine, yEntry, 0, x2);
        this.setLineEl(el.slLine, ySl, 0, x2);
        for (var i = 0; i < 3; i++) this.setLineEl(el.tpLines[i], yTps[i], x1, x2);
        this.setTagEl(el.tags.entry, yEntry, x2 - 5, true);
        this.setTagEl(el.tags.sl, ySl, x2 - 5, true);
        for (var j = 0; j < 3; j++) this.setTagEl(el.tags.tp[j], yTps[j], x2 - 5, true);
      } else {
        el.tpBox.style.display = "none";
        el.slBox.style.display = "none";
      }
    }

    var levels = this.market && this.overlays.levels ? this.market.levels : [];
    var shown = [];
    var minGap = (this.market ? this.market.atr : 1) * 0.45;
    levels.forEach(function (l) {
      if (shown.length >= 4) return;
      if (Math.abs(l.price - this.candles[this.candles.length - 1].close) < this.market.atr * 0.12) return;
      if (shown.some(function (p) { return Math.abs(p.price - l.price) < minGap; })) return;
      shown.push(l);
    }, this);
    for (var k = 0; k < this.srRows.length; k++) {
      var lv = shown[k];
      var row = this.srRows[k];
      var y = lv ? this.candleSeries.priceToCoordinate(lv.price) : null;
      if (!lv || y === null || y < 0 || y > paneH) {
        row.line.style.display = "none";
        row.tag.style.display = "none";
        continue;
      }
      row.line.style.display = "block";
      row.line.style.top = y + "px";
      row.line.style.left = "0px";
      row.line.style.width = priceAxisX + "px";
      row.tag.style.display = "block";
      row.tag.style.top = y + "px";
      row.tag.style.left = "8px";
      row.tag.style.transform = "translate(0, -50%)";
      row.tag.textContent = (lv.type === "resistance" ? "R " : "S ") + U.fmtPrice(lv.price) + "  ·" + lv.touches;
      row.tag.dataset.type = lv.type;
    }
  };

  ChartEngine.prototype.updateLast = function (bar) {
    if (!this.candles.length || !bar) return;
    var last = this.candles[this.candles.length - 1];
    if (bar.time === last.time) {
      last.high = Math.max(last.high, bar.high);
      last.low = Math.min(last.low, bar.low);
      last.close = bar.close;
      this.candleSeries.update(last);
      this.candleByTime[last.time] = last;
    } else if (bar.time > last.time) {
      this.setData(this.candles.concat([bar]), this.tfKey, { fit: false });
    }
    this.scheduleOverlay();
  };

  ChartEngine.prototype.visibleCount = function () {
    var w = this.host.clientWidth - 70;
    return Math.max(38, Math.min(130, Math.round(w / 7.5)));
  };

  ChartEngine.prototype.fit = function () {
    var t = XAU.CONFIG.timeframes[this.tfKey];
    if (!t || !this.candles.length) return;
    this.chart.timeScale().setVisibleLogicalRange({
      from: Math.max(0, this.candles.length - this.visibleCount() - 2),
      to: this.candles.length + this.futureBars - 2
    });
    this.chart.priceScale("right").applyOptions({ autoScale: true });
    this.renderOverlay();
  };

  ChartEngine.prototype.destroy = function () {
    if (this.ro) this.ro.disconnect();
    clearInterval(this.overlayTimer);
    if (this.chart) this.chart.remove();
    this.initialized = false;
  };

  XAU.ChartEngine = ChartEngine;
})();
