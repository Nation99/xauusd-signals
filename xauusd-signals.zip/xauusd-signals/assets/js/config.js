window.XAU = window.XAU || {};

XAU.CONFIG = {
  version: "1.0.0",
  product: "PAXG-USD",
  spotSymbol: "XAU",
  refreshMs: 8000,
  candleRefreshMs: 60000,
  structureRefreshMs: 180000,
  structureMinInterval: 20000,
  reentryCooldownMs: 600000,
  maxLogEntries: 80,
  futureBars: { M5: 26, M15: 20, H1: 16, H4: 16 },
  timeframes: {
    M5:  { key: "M5",  seconds: 300,   coinbase: 300,   twelve: "5min",  bars: 300, visible: 98 },
    M15: { key: "M15", seconds: 900,   coinbase: 900,   twelve: "15min", bars: 300, visible: 96 },
    H1:  { key: "H1",  seconds: 3600,  coinbase: 3600,  twelve: "1h",    bars: 300, visible: 100 },
    H4:  { key: "H4",  seconds: 14400, coinbase: 21600, twelve: "4h",    bars: 300, visible: 92 }
  },
  twelveBase: "https://api.twelvedata.com",
  spotUrl: "https://api.gold-api.com/price/XAU",
  coinbaseBase: "https://api.exchange.coinbase.com",
  storagePrefix: "xau_signal_desk:",
  defaults: {
    source: "auto",
    apiKey: "",
    sound: true,
    notify: false,
    flash: true,
    autoScale: true,
    countdown: true,
    overlays: { channels: true, levels: true, setup: true, emas: true },
    balance: 10000,
    riskPct: 1,
    tf: "H1"
  }
};

XAU.STORAGE_KEYS = {
  settings: "settings",
  log: "structure_log",
  bias: "structure_bias",
  tf: "last_tf"
};
