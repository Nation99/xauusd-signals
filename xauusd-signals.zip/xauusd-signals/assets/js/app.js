(function () {
  var CFG = XAU.CONFIG;
  var U = XAU.utils;
  var UI, E, chart, D;

  function applyStaticUI() {
    var s = E.state.settings;
    UI.setSource(E.state.source === "demo" ? "Demo" : sourceLabel(E.state.source), E.state.source !== "demo", sourceDetail());
    UI.setChartBadge(E.state.tf, sourceLabel(E.state.source));
    UI.setAlertState(!!s.sound);
    UI.setRefreshVisible(!!s.countdown);
    document.querySelectorAll(".presets button").forEach(function (b) {
      b.classList.toggle("is-active", +b.dataset.risk === +s.riskPct);
    });
    if (chart && chart.chart) chart.chart.priceScale("right").applyOptions({ autoScale: !!s.autoScale });
  }

  function sourceLabel(src) {
    return { twelvedata: "Twelve Data", coinbase: "Coinbase PAXG", demo: "Simulated", "gold-api": "gold-api" }[src] || src || "—";
  }

  function sourceDetail() {
    return "Spot: " + sourceLabel(E.state.spot ? E.state.spot.source : "—") + " · Candles: " + sourceLabel(E.state.source);
  }

  function setTfTabs(tf) {
    document.querySelectorAll(".tftab").forEach(function (b) {
      var on = b.dataset.tf === tf;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
  }

  function requestNotify() {
    if (!("Notification" in window)) return Promise.resolve(false);
    if (Notification.permission === "granted") return Promise.resolve(true);
    if (Notification.permission === "denied") return Promise.resolve(false);
    return Notification.requestPermission().then(function (p) { return p === "granted"; });
  }

  function copySignal() {
    var plan = E.activePlan();
    var entry = E.activeEntry();
    if (!plan) {
      UI.toast({ kind: "info", title: "No locked setup", msg: "Wait for a BUY or SELL signal before copying." });
      return;
    }
    var lines = [
      "XAUUSD " + plan.side + " · " + E.state.tf + " · locked setup",
      "Entry: " + U.fmtPrice(plan.entry),
      "Stop loss: " + U.fmtPrice(plan.sl),
      "TP1: " + U.fmtPrice(plan.tps[0].price) + " (" + plan.tps[0].r.toFixed(2) + "R)",
      "TP2: " + U.fmtPrice(plan.tps[1].price) + " (" + plan.tps[1].r.toFixed(2) + "R)",
      "TP3: " + U.fmtPrice(plan.tps[2].price) + " (" + plan.tps[2].r.toFixed(2) + "R)",
      "R:R 1:" + plan.rr.toFixed(2) + " · confidence " + (entry ? entry.conf : "—") + "%",
      "Generated " + U.fmtDateTime((entry ? entry.ts : Date.now()) / 1000) + " · rule-based, not financial advice"
    ];
    U.copyText(lines.join("\n")).then(function () {
      var rr = document.getElementById("sigRR");
      var old = rr.textContent;
      rr.textContent = "Copied";
      setTimeout(function () { rr.textContent = old; }, 1100);
      UI.toast({ kind: "info", title: "Setup copied", msg: "Paste it into your journal or broker ticket." });
    }).catch(function () {
      UI.toast({ kind: "err", title: "Copy failed", msg: "Clipboard permission was blocked." });
    });
  }

  function openSettings() {
    UI.openSettings(E.state.settings);
    var status = document.getElementById("keyStatus");
    status.textContent = E.state.settings.apiKey ? "A key is saved locally." : "No key saved — the free Coinbase feed is used.";
    status.className = "hint";
  }

  function saveSettings() {
    var form = UI.readSettingsForm();
    var dataChanged = E.saveSettings(form);
    if (form.notify) {
      requestNotify().then(function (ok) {
        if (!ok) UI.toast({ kind: "info", title: "Notifications blocked", msg: "Allow notifications in your browser, or keep using in-app alerts.", ttl: 7000 });
      });
    }
    UI.closeSettings();
    applyStaticUI();
    UI.toast({ kind: "info", title: "Settings saved", msg: "Alert preferences and data source updated." });

    if (dataChanged) {
      if (chart && chart.chart) chart.setPlan(E.activePlan());
      D.clearCache();
      UI.setLoading(true, "Switching data source…");
      E.loadCandles(E.state.tf, { fit: false, loader: true, forceStructure: true });
    } else if (chart && chart.chart) {
      chart.chart.priceScale("right").applyOptions({ autoScale: !!E.state.settings.autoScale });
    }
  }

  function testKey() {
    var input = document.getElementById("setApiKey");
    var status = document.getElementById("keyStatus");
    var key = input.value.trim();
    if (!key) {
      status.textContent = "Paste a key first.";
      status.className = "hint is-err";
      return;
    }
    status.textContent = "Testing key…";
    status.className = "hint";
    D.testKey(key).then(function (res) {
      status.textContent = "Key works — XAU/USD currently " + U.fmtPrice(res.price) + ". Save to switch feeds.";
      status.className = "hint is-ok";
    }).catch(function (err) {
      status.textContent = "Key failed: " + (err && err.message ? err.message : "invalid key") + ". The free Coinbase feed will be used instead.";
      status.className = "hint is-err";
    });
  }

  function toggleAlerts() {
    var s = E.state.settings;
    if (s.sound) {
      s.sound = false;
      s.notify = false;
      E.persistSettings();
      UI.setAlertState(false);
      UI.toast({ kind: "info", title: "Alerts muted", msg: "Sound and desktop alerts are off." });
      return;
    }
    s.sound = true;
    E.persistSettings();
    UI.setAlertState(true);
    try { U.beep("alert"); } catch (e) {}
    requestNotify().then(function (ok) {
      if (ok) {
        s.notify = true;
        E.persistSettings();
        UI.toast({ kind: "info", title: "Alerts on", msg: "Sound plays on new setups and desktop notifications are allowed." });
      } else {
        UI.toast({ kind: "info", title: "Sound alerts on", msg: "Desktop notifications were not allowed — you can enable them in the browser.", ttl: 7000 });
      }
    });
  }

  function recalcNow() {
    var btn = document.getElementById("recalcBtn");
    btn.classList.add("is-busy");
    E.loadCandles(E.state.tf, { fit: false, forceStructure: true, manual: true }).finally(function () {
      setTimeout(function () { btn.classList.remove("is-busy"); }, 500);
    });
  }

  function bind() {
    document.querySelectorAll(".tftab").forEach(function (b) {
      b.addEventListener("click", function () {
        setTfTabs(b.dataset.tf);
        E.switchTf(b.dataset.tf);
      });
    });

    document.querySelectorAll("[data-overlay]").forEach(function (b) {
      b.addEventListener("click", function () {
        var ov = E.toggleOverlay(b.dataset.overlay);
        document.querySelectorAll("[data-overlay]").forEach(function (x) {
          x.classList.toggle("is-on", !!ov[x.dataset.overlay]);
        });
      });
    });

    document.getElementById("settingsBtn").addEventListener("click", openSettings);
    document.getElementById("sourceBtn").addEventListener("click", openSettings);
    document.getElementById("alertBtn").addEventListener("click", toggleAlerts);
    document.getElementById("fitBtn").addEventListener("click", function () { chart.fit(); });
    document.getElementById("recalcBtn").addEventListener("click", recalcNow);
    document.getElementById("copySignalBtn").addEventListener("click", copySignal);
    document.getElementById("saveSettingsBtn").addEventListener("click", saveSettings);
    document.getElementById("testKeyBtn").addEventListener("click", testKey);

    document.getElementById("resetBtn").addEventListener("click", function () {
      if (!UI.confirmAction("Reset settings, API key and the signal log? This cannot be undone.")) return;
      Object.keys(XAU.STORAGE_KEYS).forEach(function (k) { U.storeDel(XAU.STORAGE_KEYS[k]); });
      location.reload();
    });

    document.getElementById("clearLogBtn").addEventListener("click", function () {
      if (!E.state.log.length) return;
      if (!UI.confirmAction("Clear the signal log? This removes every saved setup.")) return;
      E.clearLog();
    });

    document.querySelectorAll("[data-close]").forEach(function (b) {
      b.addEventListener("click", function () { UI.closeSettings(); });
    });

    document.querySelectorAll(".presets button").forEach(function (b) {
      b.addEventListener("click", function () {
        UI.el().calcRisk.value = b.dataset.risk;
        E.state.settings.riskPct = +b.dataset.risk;
        E.persistSettings();
        document.querySelectorAll(".presets button").forEach(function (x) { x.classList.remove("is-active"); });
        b.classList.add("is-active");
        UI.renderCalc(E.state.settings, E.activePlan());
      });
    });

    ["calcBalance", "calcRisk", "calcEntry", "calcSl"].forEach(function (id) {
      var node = document.getElementById(id);
      node.addEventListener("input", function () {
        if (id === "calcBalance") { E.state.settings.balance = U.toNum(node.value, 0); E.persistSettings(); }
        if (id === "calcRisk") {
          E.state.settings.riskPct = U.toNum(node.value, 0);
          document.querySelectorAll(".presets button").forEach(function (x) {
            x.classList.toggle("is-active", +x.dataset.risk === E.state.settings.riskPct);
          });
          E.persistSettings();
        }
        UI.renderCalc(E.state.settings, E.activePlan());
      });
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !UI.el().modal.hidden) { UI.closeSettings(); return; }
      var tag = (e.target.tagName || "").toLowerCase();
      if (tag === "input" || tag === "select" || tag === "textarea") return;
      if (e.key.toLowerCase() === "f") chart.fit();
      if (e.key.toLowerCase() === "r") recalcNow();
    });

    document.addEventListener("pointerdown", function () { U.unlockAudio(); }, { once: true });
  }

  function init() {
    UI = XAU.ui;
    D = XAU.data;
    UI.cache();

    chart = new XAU.ChartEngine(document.getElementById("chart"), document.getElementById("rrOverlay"));
    try {
      chart.init();
    } catch (err) {
      UI.setLoading(false);
      UI.showNotice("Chart library failed to initialise. Check your connection and reload.");
      return;
    }

    E = XAU.engine;
    E.init({ ui: UI, chart: chart });
    chart.setOverlays(E.state.settings.overlays);
    chart.tfKey = E.state.tf;
    setTfTabs(E.state.tf);

    document.querySelectorAll("[data-overlay]").forEach(function (b) {
      b.classList.toggle("is-on", !!E.state.settings.overlays[b.dataset.overlay]);
    });

    bind();
    applyStaticUI();
    E.start();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
