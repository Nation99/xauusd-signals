(function () {
  var CFG = XAU.CONFIG;
  var U = XAU.utils;
  var cache = {};
  var lastSpot = null;

  function fetchJSON(url, timeoutMs) {
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, timeoutMs || 12000);
    return fetch(url, { signal: ctrl.signal, cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .finally(function () { clearTimeout(timer); });
  }

  function tickerMid(j) {
    var bid = Number(j && j.bid), ask = Number(j && j.ask), last = Number(j && j.price);
    if (isFinite(bid) && isFinite(ask) && bid > 0 && ask > 0 && ask >= bid) return (bid + ask) / 2;
    if (isFinite(last) && last > 0) return last;
    return NaN;
  }

  function fetchSpot() {
    return fetchJSON(CFG.coinbaseBase + "/products/" + CFG.product + "/ticker", 9000)
      .then(function (j) {
        var price = tickerMid(j);
        if (!isFinite(price) || price <= 0) throw new Error("bad ticker");
        lastSpot = { price: price, source: "coinbase", at: Date.now(), live: true };
        return lastSpot;
      })
      .catch(function () {
        return fetchJSON(CFG.spotUrl, 9000)
          .then(function (j) {
            var price = Number(j && j.price);
            if (!isFinite(price) || price <= 0) throw new Error("bad spot payload");
            lastSpot = { price: price, source: "gold-api", at: Date.now(), live: true };
            return lastSpot;
          });
      })
      .catch(function () {
        if (lastSpot) {
          return { price: lastSpot.price, source: lastSpot.source, at: lastSpot.at, live: false };
        }
        return { price: 3560, source: "demo", at: Date.now(), live: false };
      });
  }

  function parseTwelveTime(str) {
    var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(str || "");
    if (!m) return NaN;
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) / 1000;
  }

  function normalizeCandles(candles, spotPrice) {
    if (!candles.length || !isFinite(spotPrice) || spotPrice <= 0) return candles;
    var lastClose = candles[candles.length - 1].close;
    if (!isFinite(lastClose) || lastClose <= 0) return candles;
    var factor = spotPrice / lastClose;
    if (!isFinite(factor) || factor < 0.85 || factor > 1.18) return candles;
    if (Math.abs(factor - 1) < 0.00005) return candles;
    for (var i = 0; i < candles.length; i++) {
      var c = candles[i];
      c.open = U.round(c.open * factor, 2);
      c.high = U.round(c.high * factor, 2);
      c.low = U.round(c.low * factor, 2);
      c.close = U.round(c.close * factor, 2);
    }
    return candles;
  }

  function parseRows(rows) {
    var out = [];
    if (!Array.isArray(rows)) return out;
    for (var i = rows.length - 1; i >= 0; i--) {
      var r = rows[i];
      var o = +r[3], h = +r[2], l = +r[1], c = +r[4], v = +r[5];
      if (![o, h, l, c].every(isFinite)) continue;
      if (h < Math.max(o, c) || l > Math.min(o, c)) continue;
      out.push({ time: +r[0], open: o, high: h, low: l, close: c, volume: v || 0 });
    }
    return out;
  }

  function coinbaseChunk(gran, endSec, count) {
    var start = endSec - (count - 1) * gran;
    var url = CFG.coinbaseBase + "/products/" + CFG.product + "/candles?granularity=" + gran +
      "&start=" + new Date(start * 1000).toISOString() + "&end=" + new Date(endSec * 1000).toISOString();
    return fetchJSON(url, 16000).then(parseRows);
  }

  function aggregateH4(rows) {
    var buckets = {};
    rows.forEach(function (c) {
      var b = Math.floor(c.time / 14400) * 14400;
      var cur = buckets[b];
      if (!cur) {
        buckets[b] = { time: b, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 };
      } else {
        cur.high = Math.max(cur.high, c.high);
        cur.low = Math.min(cur.low, c.low);
        cur.close = c.close;
        cur.volume += c.volume || 0;
      }
    });
    return Object.keys(buckets).map(function (k) { return buckets[k]; })
      .sort(function (a, b) { return a.time - b.time; });
  }

  function fromCoinbase(tfKey) {
    var t = CFG.timeframes[tfKey];
    var now = Math.floor(Date.now() / 1000);

    if (tfKey === "H4") {
      var end = now;
      var jobs = [];
      for (var k = 0; k < 4; k++) {
        jobs.push(coinbaseChunk(3600, end, 300));
        end -= 299 * 3600;
      }
      return Promise.all(jobs).then(function (lists) {
        var rows = [];
        lists.forEach(function (l) { rows = rows.concat(l); });
        var agg = aggregateH4(rows);
        if (agg.length < 80) throw new Error("too few candles");
        return { candles: agg.slice(-t.bars), source: "coinbase" };
      });
    }

    return coinbaseChunk(t.coinbase, now, t.bars).then(function (rows) {
      if (rows.length < 60) throw new Error("too few candles");
      return { candles: rows.slice(-t.bars), source: "coinbase" };
    });
  }

  function fromTwelve(tfKey, apiKey) {
    var t = CFG.timeframes[tfKey];
    var url = CFG.twelveBase + "/time_series?symbol=XAU/USD&interval=" + t.twelve +
      "&outputsize=" + t.bars + "&timezone=UTC&order=ASC&apikey=" + encodeURIComponent(apiKey);
    return fetchJSON(url, 16000).then(function (j) {
      if (!j || j.status === "error" || !Array.isArray(j.values)) {
        throw new Error((j && j.message) || "Twelve Data error");
      }
      var out = [];
      j.values.forEach(function (row) {
        var ts = parseTwelveTime(row.datetime);
        var o = +row.open, h = +row.high, l = +row.low, c = +row.close;
        if (!isFinite(ts) || ![o, h, l, c].every(isFinite)) return;
        out.push({ time: ts, open: o, high: h, low: l, close: c, volume: +(row.volume || 0) });
      });
      if (out.length < 60) throw new Error("too few candles");
      return { candles: out.slice(-t.bars), source: "twelvedata" };
    });
  }

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function hashString(str) {
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function demoCandles(tfKey, spotPrice) {
    var t = CFG.timeframes[tfKey];
    var sec = t.seconds;
    var n = t.bars;
    var now = Math.floor(Date.now() / 1000);
    var lastOpen = now - (now % sec);
    var day = new Date().toISOString().slice(0, 10);
    var rng = mulberry32(hashString(tfKey + "|" + day));
    var volPct = { M5: 0.00075, M15: 0.00125, H1: 0.0024, H4: 0.0042 }[tfKey] || 0.001;
    var start = (isFinite(spotPrice) ? spotPrice : 3560) * (0.985 + rng() * 0.012);
    var closes = [start];
    var phase = rng() * Math.PI * 2;
    var phase2 = rng() * Math.PI * 2;
    for (var i = 1; i < n; i++) {
      var prev = closes[i - 1];
      var wave = Math.sin(i / 27 + phase) * 0.55 + Math.sin(i / 9 + phase2) * 0.22;
      var noise = (rng() + rng() + rng() - 1.5) / 1.5;
      var drift = prev * volPct * (wave * 0.55 + noise * 0.75);
      closes.push(Math.max(prev * 0.9, prev + drift));
    }
    var scale = (isFinite(spotPrice) ? spotPrice : closes[n - 1]) / closes[n - 1];
    for (var j = 0; j < n; j++) closes[j] *= scale;

    var candles = [];
    for (var k = 0; k < n; k++) {
      var open = k === 0 ? closes[0] * (1 - volPct * 0.4) : closes[k - 1];
      var close = closes[k];
      var body = Math.abs(close - open);
      var wick = (body + open * volPct * (0.25 + rng() * 0.9));
      var high = Math.max(open, close) + wick * rng() * 0.65;
      var low = Math.min(open, close) - wick * rng() * 0.65;
      candles.push({
        time: lastOpen - (n - 1 - k) * sec,
        open: U.round(open, 2),
        high: U.round(high, 2),
        low: U.round(low, 2),
        close: U.round(close, 2),
        volume: Math.round(200 + rng() * 900)
      });
    }
    return { candles: candles, source: "demo" };
  }

  function ttlFor(tfKey, source) {
    if (source === "twelvedata") return { M5: 60000, M15: 90000, H1: 180000, H4: 300000 }[tfKey] || 120000;
    return { M5: 45000, M15: 60000, H1: 120000, H4: 180000 }[tfKey] || 90000;
  }

  function resolveSource(settings) {
    if (settings.source === "auto") return settings.apiKey ? "twelvedata" : "coinbase";
    return settings.source;
  }

  function getCandles(tfKey, settings, spot) {
    var preferred = resolveSource(settings);
    var hit = cache[tfKey];
    if (hit && Date.now() - hit.ts < ttlFor(tfKey, hit.source) && (hit.source === preferred || hit.fallback)) {
      return Promise.resolve({ candles: hit.candles, source: hit.source, cached: true });
    }

    var attempt;
    if (preferred === "demo") {
      attempt = Promise.resolve(demoCandles(tfKey, spot && spot.price));
    } else if (preferred === "twelvedata") {
      if (!settings.apiKey) {
        attempt = Promise.reject(new Error("No Twelve Data key saved"));
      } else {
        attempt = fromTwelve(tfKey, settings.apiKey)
          .catch(function () { return fromCoinbase(tfKey); })
          .catch(function () { return demoCandles(tfKey, spot && spot.price); });
      }
    } else {
      attempt = fromCoinbase(tfKey).catch(function () { return demoCandles(tfKey, spot && spot.price); });
    }

    return attempt.then(function (result) {
      var candles = normalizeCandles(result.candles, spot && spot.price);
      cache[tfKey] = { candles: candles, source: result.source, ts: Date.now(), fallback: result.source !== preferred };
      return { candles: candles, source: result.source, cached: false };
    });
  }

  function clearCache() { cache = {}; }

  function testKey(key) {
    if (!key) return Promise.reject(new Error("Enter a key first"));
    var url = CFG.twelveBase + "/quote?symbol=XAU/USD&apikey=" + encodeURIComponent(key);
    return fetchJSON(url, 12000).then(function (j) {
      if (j && j.status === "error") throw new Error(j.message || "Key rejected");
      if (!j || (!j.close && !j.price)) throw new Error("Unexpected response");
      var price = +(j.close || j.price);
      if (!isFinite(price)) throw new Error("Unexpected response");
      return { price: price, currency: j.currency || "USD" };
    });
  }

  XAU.data = {
    fetchSpot: fetchSpot,
    getCandles: getCandles,
    testKey: testKey,
    clearCache: clearCache,
    demoCandles: demoCandles,
    resolveSource: resolveSource
  };
})();
